# Supplement: genome-wide OpenSpliceAI and SpliceAI comparison

## Abstract

We describe the scoring collection, annotation pairing, masking, and statistical summaries used to compare OpenSpliceAI with SpliceAI. Supporting analyses examine score differences, threshold transfer, output precision, annotation context, selected positions, and variation across genes and genomic blocks. All results use the same dated scientific snapshot as the main report; inference progress is documented separately.



This supplement accompanies the [main report](/reports/full-snv-scoring-technical-report/).
AG, AL, DG and DL denote acceptor gain, acceptor loss, donor gain and donor loss, respectively.
MAX is the largest of those four scores. Scientific results use the September 9 snapshot;
separately dated progress observations do not change the analyzed populations.

## Detailed methods

### Scoring collection and models

We used the published masked genic SNV collection distributed with SpliceAI. The collection includes
genic positions and flanking sequence and does not enumerate all possible substitutions at every
reference base. The campaign divides the source into 100,000 chunks. We scored
MANE-trained OpenSpliceAI checkpoints from seeds rs10 and rs13, each using a single checkpoint.
The published SpliceAI scores were produced by a five-model ensemble. The seed labels do not refer to
cross-validation folds. The comparison therefore combines differences in training, checkpoints,
implementation and ensembling.

The recorded setup uses GRCh38.p14, the GENCODE v24 canonical gene table supplied with SpliceAI,
a 10,000-nt model context, a ±50-bp event-search window, and masked output.
Training annotations and scoring annotations have different roles: MANE defines the retraining data,
whereas the campaign's shared canonical gene table controls assignment and masking.
For each event, the score is the largest predicted increase or decrease in the event-search window;
its accompanying delta position records the selected location relative to the variant.

### Audit, pairing and comparison domains

Input and output VCFs were audited for completeness, parseability, source-record preservation and
annotation structure. The analysis pins source artifacts and manifests by checksum and verifies
selected chunk identities. A valid structural audit does not establish the checkpoint that produced
a legacy file. We retain the classification `legacy_unprovenanced` and do not infer embedded provenance
receipts from campaign settings alone.

We pair by chromosome, position, reference allele, alternate allele and exact gene label. We collapse
identical duplicate values and exclude conflicting duplicates. An absent model score is missing, not
zero. Chunk-boundary joining resolves groups split by file partitioning. We retain separate counts
for physical VCF records, distinct variant alleles, gene annotations and paired observations.

<figure><img src="figures/supp01_coverage.png" alt="Source records, variant groups and paired gene annotations have different denominators." /><figcaption>Figure S1. Counting units and pairing coverage. Counts refer to the primary rs10 comparison. VCF rows, distinct variant groups and variant–gene annotations are different units; these rows are not successive stages of a decreasing funnel. Pairing excludes missing or conflicting predictions. Counts for each model use its name explicitly. Coverage remains provisional.</figcaption></figure>

| Arm | Comparison | Role | Chunks | Paired annotations | Status |
| :--- | ---: | ---: | ---: | ---: | ---: |
| **A_rs10_genomewide** | SpliceAI vs OpenSpliceAI | primary | 99,283 | 3,334,708,099 | provisional |
| **B_seeds_rs10_rs13** | rs10 vs rs13 | seed | 45,589 | 1,536,316,689 | provisional |
| **C_rs10_matched** | SpliceAI vs rs10 | matched | 45,589 | 1,536,316,689 | provisional |
| **D_rs13_matched** | SpliceAI vs rs13 | matched | 45,589 | 1,536,316,689 | provisional |

The primary comparison uses the available rs10 domain. The other three arms compare rs10 with rs13,
SpliceAI with rs10, and SpliceAI with rs13 on one exact three-way intersection after duplicate
resolution. Each has 1,536,316,689 observations across
45,589 chunks. The matched region covers chunks 1-46,920, ending at chr7:152,826,580;
its genomic restriction prevents treating it as a random subset of the full collection.

| Quantity | Count | Meaning |
| :--- | ---: | :--- |
| Retained VCF rows | 3,408,766,953 | rows entering aggregation after incomplete edge groups are excluded |
| Variant groups | 3,321,262,905 | distinct (CHROM, POS, REF, ALT) |
| SpliceAI annotations | 3,408,658,794 | valid, deduplicated, allele-matched |
| OpenSpliceAI annotations | 3,334,713,875 | valid, deduplicated, allele-matched |
| **Exact-gene paired** | **3,334,708,099** | **the denominator of every paired statistic** |
| SpliceAI-only annotations | 73,950,695 | gene absent from the OpenSpliceAI output |
| OpenSpliceAI-only annotations | 5,776 | gene absent from the SpliceAI source |
| Groups without any prediction | 66,560,405 | no OpenSpliceAI value on any row |
| Conflicting SpliceAI values | 50,538 | excluded from paired metrics |
| Conflicting OpenSpliceAI values | 2,261 | excluded from paired metrics |
| Duplicate annotations | 261,358,769 | identical repeats, collapsed |
| Malformed annotations | 0 | rejected |
| Edge fragments excluded | 92 | groups touching a missing chunk |

Of the SpliceAI annotations, 97.83% could be paired with an OpenSpliceAI annotation for the same gene.

### Streaming summaries and numerical verification

The analysis reduces streams of paired annotations to additive counts, moments, fixed-bin
histograms, and stratum tables. It does not materialize a multi-billion-row dataframe. Exact
threshold counters use 0.05, 0.1, 0.2, 0.5 and 0.8, with positive calls defined by score ≥ cutoff.
The 200-bin score histograms have width 0.005; conditional quantiles and threshold sweeps derived
from them are approximate. Empty bins remain gaps. Undefined rates remain undefined rather than
being replaced with zero.

All event-level global score summaries use the full paired domain, including shared zeros. Pearson
correlation describes association, mean absolute difference describes score magnitude, and signed
bias is OpenSpliceAI minus SpliceAI. Jaccard is the intersection divided by the union of positive
calls. The call-count ratio is OpenSpliceAI divided by SpliceAI. Comparator-based MCC and related
agreement statistics are not experimental accuracy measures.

The reducer checks missing and duplicate tasks, pair-domain completeness and source identity.
Independent real-data-window implementations passed 11,195 primary
and 40,020 matched numerical checks. These validate the implemented
computations on the tested windows, not biological truth or completeness of unfinished inference.
The archived September 9 bundle retains the original engineering narrative and verification evidence.

### Annotation context and masking

The proximity index contains 351,042 unique internal boundary coordinates from the
scoring annotation. Donor and acceptor roles are assigned by strand. Internal boundaries are pooled
across genes, and transcript ends are excluded. We group variants by the distance of the variant
coordinate to the nearest indexed boundary: at-site, 1–2, 3–10, 11–50, 51–500 and >500 bp. The main
figure pools acceptor, donor and ambiguous context by summing call numerators and denominators before computing rates.
The original tables preserve the site-type strata.

The scorer's mask uses a different boundary set: it selects the nearest exon boundary for the
specific variant–gene annotation, including transcript ends and pooling donor/acceptor boundary
types. Under the recorded implementation, a loss is retained only if its selected delta position equals
that boundary, and a gain there is suppressed. This describes the intended masking rule; the rare
loss-position discrepancies in legacy outputs are reported separately below. The mask acts on the selected event position, whereas proximity grouping
uses the variant position. This distinction explains why pooled distance and retained loss location
must not be interpreted as independent biological labels.

A symmetric 1–2-bp distance group includes both sides of a boundary and is not synonymous with the
essential splice dinucleotide. A distance >500 bp does not establish a deep-intronic variant: the
index is pooled and no transcript-specific intronic/exonic classification was performed. Far-loss
strata may be empty or very small under the mask; eligible counts are needed to interpret their rates.

### Current inference progress

The progress collector reads the dated campaign manifests and verifies their checksums, seed labels,
complete unique chunk IDs, state totals and provenance totals against the audit metadata. It then
compares current input and output file sizes and nanosecond modification times with those recorded
in each manifest. Unchanged files retain their audited classification; changed or newly appearing
files are unverified, and absent files are missing. An I/O failure cannot produce a valid count.
This metadata comparison is deliberately separate from a new VCF content audit.

The scheduler query records matching rs10 and rs13 scoring jobs with their states and reasons. A
failed query is reported as unavailable, rather than as no jobs. The displayed observation time and
original audit time remain separate. No inference jobs or campaign manifests are changed by this
report revision, and no completion date is inferred from a pending job.

## Secondary event comparisons

### Signed differences and threshold transfer

Signed-difference tails separate annotations where OpenSpliceAI exceeds SpliceAI from those with
the reverse ordering. Gain differences favor higher SpliceAI scores over much of the displayed tail
range. For losses, large differences more often have higher OpenSpliceAI scores. Tail probabilities
use the full paired population and approximate histogram magnitudes. Neither the sign nor the size
of a model difference determines whether the predicted effect occurs experimentally.

<figure><img src="figures/supp02_tails.png" alt="Signed score-difference tails by event." /><figcaption>Figure S2. The direction of large score differences. Tail probabilities distinguish OpenSpliceAI exceeding SpliceAI from the reverse. The right panel compares these directions. Difference magnitudes use histogram centers and estimates are approximate. This supports, rather than replaces, the event-wise score and call comparisons.</figcaption></figure>

| Event | n | Mean SpliceAI | Mean OpenSpliceAI | Bias | MAE | RMSE | Pearson r | Lin CCC | Spearman* |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| acceptor gain (AG) | 3,334,708,099 | 0.00173 | 0.00060 | -0.00112 | 0.00148 | 0.01592 | 0.6810 | 0.6663 | 0.3357 |
| acceptor loss (AL) | 3,334,708,099 | 0.00068 | 0.00079 | +0.00011 | 0.00037 | 0.01009 | 0.8998 | 0.8941 | 0.7197 |
| donor gain (DG) | 3,334,708,099 | 0.00166 | 0.00046 | -0.00120 | 0.00147 | 0.01722 | 0.5973 | 0.5576 | 0.3201 |
| donor loss (DL) | 3,334,708,099 | 0.00067 | 0.00077 | +0.00010 | 0.00033 | 0.00994 | 0.9056 | 0.9022 | 0.6914 |
| maximum (MAX) | 3,334,708,099 | 0.00420 | 0.00217 | -0.00203 | 0.00315 | 0.02452 | 0.7945 | 0.7903 | 0.3901 |

*Spearman correlations are approximations calculated from the 200-bin joint score histograms, not exact ranks of the original scores.*

Call-volume matching asks which OpenSpliceAI cutoff produces a similar number of calls to a given
SpliceAI cutoff. MCC optimization asks which candidate cutoff maximizes agreement with SpliceAI.
These objectives can select different cutoffs because equal volumes need not contain the same
annotations. Neither supplies a biologically validated decision threshold.

<figure><img src="figures/supp03_threshold_transfer.png" alt="Per-event cutoffs selected by call-volume matching or comparator MCC." /><figcaption>Figure S3. Matching call volume does not ensure matching membership. Every configured SpliceAI cutoff is shown. Candidate OpenSpliceAI cutoffs lie on the histogram grid and exclude the unresolved endpoint at one. MCC is agreement with SpliceAI; neither objective optimizes experimental accuracy.</figcaption></figure>

| Event | SpliceAI cutoff | MCC at same cutoff | Rate-matched OSAI cutoff | MCC-optimal OSAI cutoff | Optimised MCC |
| :--- | ---: | ---: | ---: | ---: | ---: |
| AG | 0.05 | 0.362 | 0.005 | 0.005 | 0.438 |
| AG | 0.1 | 0.400 | 0.010 | 0.010 | 0.431 |
| AG | 0.2 | 0.457 | 0.055 | 0.200 | 0.457 |
| AG | 0.5 | 0.589 | 0.380 | 0.590 | 0.593 |
| AG | 0.8 | 0.633 | 0.830 | 0.825 | 0.634 |
| AL | 0.05 | 0.702 | 0.040 | 0.040 | 0.703 |
| AL | 0.1 | 0.709 | 0.110 | 0.130 | 0.711 |
| AL | 0.2 | 0.729 | 0.275 | 0.355 | 0.747 |
| AL | 0.5 | 0.794 | 0.725 | 0.765 | 0.835 |
| AL | 0.8 | 0.828 | 0.925 | 0.905 | 0.846 |
| DG | 0.05 | 0.341 | 0.005 | 0.005 | 0.430 |
| DG | 0.1 | 0.372 | 0.010 | 0.005 | 0.426 |
| DG | 0.2 | 0.411 | 0.035 | 0.115 | 0.416 |
| DG | 0.5 | 0.465 | 0.235 | 0.400 | 0.470 |
| DG | 0.8 | 0.459 | 0.745 | 0.685 | 0.465 |
| DL | 0.05 | 0.714 | 0.055 | 0.080 | 0.720 |
| DL | 0.1 | 0.748 | 0.125 | 0.180 | 0.762 |
| DL | 0.2 | 0.784 | 0.275 | 0.340 | 0.800 |
| DL | 0.5 | 0.810 | 0.665 | 0.640 | 0.818 |
| DL | 0.8 | 0.793 | 0.900 | 0.880 | 0.800 |
| MAX | 0.05 | 0.432 | 0.005 | 0.005 | 0.477 |
| MAX | 0.1 | 0.485 | 0.015 | 0.065 | 0.487 |
| MAX | 0.2 | 0.559 | 0.080 | 0.260 | 0.562 |
| MAX | 0.5 | 0.704 | 0.420 | 0.655 | 0.715 |
| MAX | 0.8 | 0.780 | 0.835 | 0.880 | 0.787 |

### Precision and dominant events

SpliceAI reports two decimal places and OpenSpliceAI five. Rounding OpenSpliceAI to two decimals
increases the exact-match rate from 89.55% to 96.58% for AG and from 90.75% to 96.78% for DG.
The corresponding loss rates already exceed 99% before rounding because the full population contains
many shared zeros. Exact equality therefore describes both score precision and score distribution.

We also calculated the mean residual after subtracting 0.005 from each absolute score difference
and setting negative residuals to zero. Dividing this mean by the original MAE gives 0.878 for AG,
0.925 for AL, 0.885 for DG and 0.922 for DL. This is a share of absolute error, not a percentage of
variants. The allowance is a sensitivity analysis for the reported-score grid; it does not recover
unrounded scores or identify how much of the difference was caused by output rounding. In particular,
a strict bound involving both output formats would also account for OpenSpliceAI's finer rounding.

<figure><img src="figures/supp04_precision.png" alt="Exact score agreement after matching output precision and differences beyond the rounding allowance." /><figcaption>Figure S4. Score agreement under a rounding allowance. SpliceAI reports two decimal places and OpenSpliceAI five. Left, exact matches before and after rounding OpenSpliceAI to two decimals. Right, mean(max(|OpenSpliceAI − SpliceAI| − 0.005, 0)) divided by the original mean absolute difference. This is a residual-error share, not a fraction of discordant variants or an estimate of error caused by rounding. The 0.005 allowance is an operational sensitivity analysis; it does not reconstruct either model’s unrounded scores. Shared zeros remain in the denominator.</figcaption></figure>

| Event | MAE | MAE (OSAI at 2 dp) | Exact match | Exact match (2 dp) | Change | MAE beyond +/-0.005 | Share of MAE |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| acceptor gain (AG) | 0.001481 | 0.001482 | 89.55% | 96.58% | +7.03 pp | 0.001300 | 87.8% |
| acceptor loss (AL) | 0.000369 | 0.000366 | 99.06% | 99.54% | +0.48 pp | 0.000341 | 92.5% |
| donor gain (DG) | 0.001465 | 0.001467 | 90.75% | 96.78% | +6.03 pp | 0.001297 | 88.5% |
| donor loss (DL) | 0.000333 | 0.000331 | 99.06% | 99.58% | +0.52 pp | 0.000307 | 92.2% |
| maximum (MAX) | 0.003145 | 0.003148 | 82.11% | 93.27% | +11.16 pp | 0.002788 | 88.6% |

The dominant event is the largest of the four scores within one model. TIE records a tied nonzero
maximum and NONE records all-zero scores. The heatmap normalizes each row by its SpliceAI-category
count, which is printed beside the row. Cells below 0.005 have no numerical label but may contain
observations. Exact counts accompany the figure. These dominant labels are exclusive by construction;
the underlying predicted events are not. Quantization can change both ties and the selected label.

<figure><img src="figures/supp05_dominant_event.png" alt="Row-normalized dominant-event transitions, retaining ties and all-zero annotations." /><figcaption>Figure S5. Dominant-event labels and their denominators. Each row is normalized by its displayed SpliceAI-category count. TIE denotes a tied nonzero maximum and NONE all-zero scores. Unlabelled cells have proportions below 0.005, not necessarily zero; displayed rounding can prevent row labels summing to one. Exact counts and proportions are supplied in figure_data/dominant_row_proportions.csv. Dominant labels compress four nonexclusive scores.</figcaption></figure>

## Context and selected positions

Survival curves show the fraction of scores at or above each histogram edge. The near population
contains 5,431,412 paired annotations at or within 2 bp of an internal boundary; the far population
contains 2,805,642,585 more than 500 bp away. Each curve uses its own population as the denominator,
and all panels share the same logarithmic rate scale. Zero survival values cannot be drawn on
that scale. A far-loss curve visible only at cutoff zero does not demonstrate nonzero loss calls.
The curves include MAX to show how combining events can obscure their different distributions.

<figure><img src="figures/supp06_site_distributions.png" alt="Event-score survival distributions near and far from internal boundaries, including MAX." /><figcaption>Figure S6. Score distributions near and far from internal boundaries. Histogram survival curves show the fraction at or above each lower bin edge, using width 0.005. All panels share the same logarithmic rate scale and include MAX as a summary. The near population contains 5,431,412 annotations and the far population 2,805,642,585. Zero survival values cannot appear on the log axis; a point at cutoff zero alone does not establish a nonzero loss score. The far group is not a transcript-specific deep-intronic category.</figcaption></figure>

Conditional plots use the same near and far populations, separating the four events and MAX.
Points are medians and intervals contain the central 50% of OpenSpliceAI scores within a SpliceAI
histogram bin. Empty bins are gaps, and occupied-bin sample sizes vary. The intervals describe
score distributions rather than uncertainty in a fitted mean. Near-boundary gain medians lie
closer to equal scores across much of the comparator range. This observation neither establishes
experimental calibration nor classifies the distant predictions as false.

<figure><img src="figures/supp07_site_score_agreement.png" alt="Near and distant score distributions for gains and losses." /><figcaption>Figure S7. Conditional score distributions by boundary proximity. Points are histogram-derived conditional medians and intervals the central 50% of OpenSpliceAI scores for each SpliceAI bin. Empty bins remain gaps. Near and far populations contain 5,431,412 and 2,805,642,585 annotations, respectively; the number in each conditioning bin varies. These are distribution intervals, not confidence intervals or calibration against experimental outcomes. MAX is a summary of the four events.</figcaption></figure>

Position agreement requires both event scores to be at least 0.5. All panels retain the same six
distance categories; groups with no jointly called events have undefined agreement. Eligible counts
and exact-position mismatches are printed in each panel. The AL exception occurs in the 11–50-bp
acceptor group. Three DL exceptions occur in the 11–50-bp donor group and one in the 3–10-bp donor
group. These are variant-to-boundary distances, not distances between selected positions.

The AL mismatch has a 2-bp position difference. The four DL differences exceed 2 bp and are at most
5 bp. Thus, even the near-complete loss agreement should not be described as exact for every
annotation. Checksummed source and output records identify all four DL exceptions in TVP23C-CDRT4 and the AL
exception in XAGE3. The DL calls select chr17:15,440,211 in SpliceAI versus chr17:15,440,208 in
OpenSpliceAI; the AL call selects chrX:52,866,536 versus chrX:52,866,538. In each case the OpenSpliceAI
position matches the nearest boundary in the campaign annotation. The published SpliceAI position
does not. This establishes a local discrepancy in retained positions, not its historical cause;
we cannot infer whether it arose from annotation preparation, coordinate conversion or another
legacy processing step. The audit contains exact variants, scores and file checksums. High agreement among shared calls cannot establish localization accuracy
or describe predictions made by only one model.

<figure><img src="figures/supp08_site_positions.png" alt="Exact and within-2-bp position agreement by event and annotation context at a score cutoff of 0.5." /><figcaption>Figure S8. Position agreement within jointly called distance groups. Exact and within-2-bp agreement require both event scores ≥0.5. All panels retain the same six variant-distance groups. A group without jointly called events has undefined agreement and is labelled No joint calls. Vertical labels give eligible counts and exact-position mismatches (miss). The complete table includes other cutoffs and tolerances. Rare AL and DL mismatches are preserved rather than hidden by rounded percentages.</figcaption></figure>

| Event | Jointly called (≥0.5) | Exact positions | Mismatches |
| :--- | ---: | ---: | ---: |
| acceptor gain (AG) | 801,905 | 776,454 | 25,451 |
| acceptor loss (AL) | 1,441,730 | 1,441,729 | 1 |
| donor gain (DG) | 576,354 | 565,323 | 11,031 |
| donor loss (DL) | 1,630,987 | 1,630,983 | 4 |

## Seed comparisons and genomic heterogeneity

Gene-level method-to-seed ratios use the same three-way matched observations as Figure 6. Before
filtering ratios, 7,493 genes have at least 1,000 paired annotations. All 7,493 contribute positive,
defined AG and DG ratios for both checkpoints. The plotted AL populations contain 7,048 genes for
rs10 and 7,052 for rs13; DL populations contain 7,069 and 7,071. The accompanying summary table
records the excluded counts. Zero or undefined ratios are excluded from the logarithmic display,
not interpreted as missing biological effects or infinite differences.

Median AG ratios are approximately 3.59 for both checkpoints, and median DG ratios are 4.17 and
4.16. Loss medians are closer to one: 1.18 and 1.14 for AL, and 1.21 and 1.13 for DL. Approximately
66–78% of the retained loss ratios exceed one, compared with more than 99.8% for gains. Each gene
has equal weight in these distributions, whereas global MAEs weight individual annotations.
Very small seed MAEs can generate extreme ratios without a correspondingly large absolute error.

<figure><img src="figures/supp09_seed_by_gene.png" alt="Gene-level method-to-seed mean absolute difference ratios." /><figcaption>Figure S9. Distribution of gene-level method-to-seed differences. Empirical cumulative distributions use the exact three-way intersection, with at least 1,000 paired observations per gene and positive, defined MAE ratios. All panels share log-axis limits. Legends give plotted gene counts; figure_data/seed_gene_summary.csv records exclusions, medians and fractions above one. Genes contribute equal weight to each curve. A small seed MAE can produce a large ratio; zero-denominator ratios are undefined.</figcaption></figure>

| Event | Seed r | Seed MAE | Method r (rs10) | Method MAE (rs10) | Method r (rs13) | Method MAE (rs13) | MAE ratio method/seed |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| acceptor gain (AG) | 0.8313 | 0.00040 | 0.6857 | 0.00134 | 0.6854 | 0.00134 | x3.35 / x3.35 |
| acceptor loss (AL) | 0.9147 | 0.00031 | 0.8966 | 0.00035 | 0.9019 | 0.00033 | x1.13 / x1.08 |
| donor gain (DG) | 0.7990 | 0.00033 | 0.6041 | 0.00131 | 0.6070 | 0.00131 | x3.92 / x3.92 |
| donor loss (DL) | 0.9255 | 0.00027 | 0.9037 | 0.00031 | 0.9128 | 0.00029 | x1.17 / x1.09 |
| maximum (MAX) | 0.8917 | 0.00108 | 0.7956 | 0.00285 | 0.7989 | 0.00283 | x2.65 / x2.63 |

Regional MAX means summarize 2,571 blocks with at least 10,000 paired annotations. Mean signed
differences span −0.02608 to +0.00182. Every retained block is shown across the full vertical range.
Blocks are equally spaced within each chromosome, so horizontal distances are not proportional to
genomic length. Point area increases with annotation count using an offset and scaled count. These
regional averages combine event types and variant composition; they do not identify an event-specific
mechanism or establish genomic enrichment.

<figure><img src="figures/supp10_chromosome.png" alt="Mean signed MAX differences in all eligible 1-Mb blocks." /><figcaption>Figure S10. Regional variation in mean MAX differences. All 2,571 retained 1-Mb blocks with at least 10,000 paired annotations are shown across their full value range. Blocks are equally spaced within each chromosome; the horizontal scale is not proportional to genomic length. Point area increases with annotation count using an offset plus a scaled count. The dashed line is the primary annotation-weighted mean. MAX averages do not identify an event-specific regional mechanism.</figcaption></figure>

The gene analysis retains 19,063 genes with at least 1,000 paired annotations. Of these, 18,881
have a negative mean MAX difference, with a median across genes of −0.00302. The scatter and
histogram display this same population. Labels are selected from negative differences subject to
spacing, rather than marking a strict ranking of the twelve most negative genes.

The scatter uses x=mean SpliceAI MAX and y=mean OpenSpliceAI MAX−x. These axes share a term, and
nonnegative OpenSpliceAI scores impose y≥−x. The resulting mathematical coupling must not be
interpreted as a biological relationship between signal strength and model divergence. Genes with
large differences are descriptive follow-up candidates, not validated disease associations.

<figure><img src="figures/supp11_gene_divergence.png" alt="Gene-level MAX disagreement and selected high-divergence genes." /><figcaption>Figure S11. Distribution of gene-level mean MAX differences. Both panels contain 19,063 genes with at least 1,000 paired annotations. Point area increases linearly with annotation count after scaling. Up to twelve labels are selected in order of negative mean difference subject to spacing, so they are not strictly the twelve most negative genes. The scatter compares x=mean SpliceAI MAX with y=mean OpenSpliceAI MAX−x; the shared x term and bound y≥−x create mathematical coupling. The histogram shows the same gene differences and their median. Neither panel tests enrichment or establishes disease associations.</figcaption></figure>

## Complete data and reproducibility

The [study bundle](/downloads/full-snv-concordance-20260910-r2.zip) contains both reading copies, the figure
manifest, all seventeen PNG/PDF figure pairs, unchanged scientific facts, a separate progress JSON,
display histograms and derived display tables, selected original CSV tables, and the report source. Figure
captions and numbers are generated from one manifest for the website and standalone reading copies.
The [scientific audit](/downloads/full-snv-concordance-20260910-r2-figure-audit.md) documents the source evidence,
figure decisions, numerical checks and remaining limitations.
The [standalone supplement](/downloads/full-snv-concordance-20260910-r2-supplement.html) and
[checksums](/downloads/full-snv-concordance-20260910-r2-SHA256SUMS.txt) can be read separately.

Complete original CSV archives remain available for the
[primary rs10 comparison](/downloads/full-snv-concordance-20260909-A_rs10_genomewide.zip),
[rs10–rs13 seed comparison](/downloads/full-snv-concordance-20260909-B_seeds_rs10_rs13.zip),
[matched SpliceAI–rs10 comparison](/downloads/full-snv-concordance-20260909-C_rs10_matched.zip), and
[matched SpliceAI–rs13 comparison](/downloads/full-snv-concordance-20260909-D_rs13_matched.zip).
These include chromosome, gene, substitution, genomic-block, event-context, collapsed-variant,
discordance and threshold tables. The unchanged
[September 9 release](/downloads/full-snv-concordance-20260909.zip) preserves the full original report,
all original figures, engineering history and verification records.
