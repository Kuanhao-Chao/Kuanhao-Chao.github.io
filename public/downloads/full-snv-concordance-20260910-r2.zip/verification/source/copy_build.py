"""Copy a completed static build with bounded parallel filesystem operations."""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import shutil
import sys

source,destination=map(lambda p:Path(p).resolve(),sys.argv[1:3])
destination.mkdir(parents=True,exist_ok=False)
paths=list(source.rglob('*'))
for p in paths:
    if p.is_dir() and not p.is_symlink():
        (destination/p.relative_to(source)).mkdir(parents=True,exist_ok=True)
files=[p for p in paths if not p.is_dir() or p.is_symlink()]
def copy(p):
    target=destination/p.relative_to(source)
    if p.is_symlink():
        target.symlink_to(p.readlink(),target_is_directory=p.is_dir())
    else:
        shutil.copy2(p,target)
        if target.stat().st_size!=p.stat().st_size:
            raise ValueError('build copy size mismatch: '+str(p))
with ThreadPoolExecutor(max_workers=16) as pool:
    list(pool.map(copy,files))
print(json.dumps(dict(source=str(source),destination=str(destination),files=len(files),status='copied')))
