import csv,hashlib,json
from pathlib import Path
b=Path('results/full_snv_concordance/study_20260908_depth/revision_20260910_r2/verification')
rows=list(csv.DictReader((b/'position_exception_records.csv').open()))
genes={r['#NAME']:r for r in csv.DictReader(Path('data/grch38_chr.txt').open(),delimiter='\t')}
annotation_hash=hashlib.sha256(Path('data/grch38_chr.txt').read_bytes()).hexdigest()
maps=json.loads((b/'position_exception_maps.json').read_text())
receipts={c['chunk_id']:c for m in maps['maps'] for c in m['files']}
source_cache={}
for row in rows:
 chunk=row['chunk'];receipt=next(r for r in receipts[chunk]['vcfs'] if r['role']=='source')
 if chunk not in source_cache:
  raw=Path(receipt['path']).read_bytes()
  assert hashlib.sha256(raw).hexdigest()==receipt['file_sha256']
  source_cache[chunk]=[r.split('\t') for r in raw.decode().splitlines() if not r.startswith('#')]
 values=set()
 for r in source_cache[chunk]:
  if r[0]!=row['chrom'] or r[1]!=row['pos'] or r[3]!=row['ref']:continue
  info=dict(x.split('=',1) for x in r[7].split(';') if '=' in x)
  for a in info.get('SpliceAI','').split(','):
   f=a.split('|')
   if len(f)==10 and f[0]==row['alt'] and f[1]==row['gene']:values.add(tuple(f))
 assert len(values)==1
 f=next(iter(values));i=1 if row['event']=='AL' else 3
 assert float(f[2+i])==float(row['spliceai_score']) and int(f[6+i])==int(row['spliceai_dp'])
 gene=genes[row['gene']]
 boundaries=sorted({int(x)+1 for x in gene['EXON_START'].split(',') if x}|{int(x) for x in gene['EXON_END'].split(',') if x})
 position=int(row['pos']);nearest=min(boundaries,key=lambda x:abs(x-position))
 row.update(strand=gene['STRAND'],spliceai_selected=position+int(row['spliceai_dp']),openspliceai_selected=position+int(row['openspliceai_dp']),nearest_gene_boundary=nearest,
            spliceai_matches_boundary=position+int(row['spliceai_dp'])==nearest,openspliceai_matches_boundary=position+int(row['openspliceai_dp'])==nearest,
            original_spliceai_verified=True,annotation_sha256=annotation_hash,source_vcf_sha256=receipt['file_sha256'])
with (b/'position_exception_records.csv').open('w') as h:
 w=csv.DictWriter(h,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(json.dumps(rows,indent=2))
