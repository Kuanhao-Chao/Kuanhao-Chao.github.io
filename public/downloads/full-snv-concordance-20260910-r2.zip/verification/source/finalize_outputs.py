"""Package verified report PDFs and receipts, then validate the final archive."""
import csv
import hashlib
import json
from pathlib import Path
import shutil
import re
import subprocess
import sys
import zipfile


sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
from validation.concordance_study.prepare_release import archive, digest

REV=Path(__file__).resolve().parent
BASE=REV.parent
ROOT=BASE.parents[2]
OUT=REV/'publication'
EVIDENCE=REV/'verification'
WEBSITE=BASE/'website-release'
DOWNLOADS=WEBSITE/'public/downloads'
PREFIX='full-snv-concordance-20260910-r2'
BUILD=Path((EVIDENCE/'build-path.txt').read_text().strip())
assert BUILD.name != 'build-30791024', 'preliminary candidate is not the final build'
gates=list(csv.DictReader((EVIDENCE/'website-gates.tsv').open(),delimiter='\t'))
assert gates[-1]['gate']=='all' and gates[-1]['status']=='passed'
assert '86 passed' in (EVIDENCE/'python-tests.log').read_text()
assert 'All checks passed' in (EVIDENCE/'ruff.log').read_text()
assert digest(BASE/'publication/study_facts.json')==digest(OUT/'study_facts.json')=='51c6ae93c09e0652e39004a846258b8b7a0bf1e890123e698373d397f46c8c06'
# Previously published downloads are tracked in the baseline website commit.
unchanged=subprocess.run(['git','-C',str(WEBSITE),'diff','--exit-code','8da4d712','--','public/downloads/full-snv-concordance-20260909*','public/downloads/full-snv-concordance-20260910.zip','public/downloads/full-snv-concordance-20260910.html','public/downloads/full-snv-concordance-20260910-supplement.html','public/downloads/full-snv-concordance-20260910-SHA256SUMS.txt','public/downloads/full-snv-concordance-20260910/'],capture_output=True,text=True)
if unchanged.returncode:
    raise ValueError('previously published downloads changed: '+unchanged.stdout[:1000])
page_dir=EVIDENCE/'pdf-pages';page_dir.mkdir(exist_ok=True)
pdfs=[]
for slug,expected in [('full-snv-scoring-technical-report',6),('full-snv-scoring-supplement',11)]:
    source=BUILD/'reports'/slug/(slug+'.pdf')
    assert source.stat().st_size<5_000_000
    shutil.copy2(source,OUT/(slug+'.pdf'))
    details=subprocess.run(['/usr/bin/pdfinfo',str(source)],capture_output=True,text=True,check=True).stdout
    pages=int(re.search(r'^Pages:\s+(\d+)',details,re.M).group(1))
    text=subprocess.run(['/usr/bin/pdftotext','-layout',str(source),'-'],capture_output=True,text=True,check=True).stdout
    assert '3,334,708,099' in text and '1,441,729' in text and '1,630,983' in text
    assert '{{' not in text and 'INTERPRET' not in text
    for i in range(1,expected+1):
        number=('S' if 'supplement' in slug else '')+str(i)
        assert 'Figure '+number+'.' in text, (slug,number)
    subprocess.run(['/usr/bin/pdftoppm','-scale-to','1600','-png',str(source),str(page_dir/slug)],check=True)
    pdfs.append(dict(document=slug,pages=pages,bytes=source.stat().st_size,sha256=digest(source)))
    (EVIDENCE/(slug+'-pdf.txt')).write_text(text)
receipt=dict(status='passed',pdfs=pdfs,original_downloads_unchanged=True,frozen_facts_unchanged=True,website_build=str(BUILD))
(EVIDENCE/'artifact-checks.json').write_text(json.dumps(receipt,indent=2)+'\n')
for name in ['artifact-checks.json','python-tests.log','ruff.log','website-gates.tsv','report-browser-review.json','figure-review.json','scientific-checks.json','claim-sources.csv','numerical-checks.csv','position_exception_records.csv','position-exception-context.csv','position_exception_maps.json','source-sync.json']:
    (OUT/'verification').mkdir(exist_ok=True)
    shutil.copy2(EVIDENCE/name,OUT/'verification'/name)
for name in ['verify_positions.py','verify_position_boundaries.py','finalize_outputs.py','final-gates.sbatch','final-rounding-gates.sbatch','build-final-website.sh','copy_build.py']:
    (OUT/'verification/source').mkdir(parents=True,exist_ok=True)
    shutil.copy2(REV/name,OUT/'verification/source'/name)
from validation.concordance_study.concise_release import TEMPLATES, figure_audit
(OUT/'figure_audit.md').write_text((TEMPLATES/'scientific-review.md').read_text()+'\n\n## Original-to-current figure mapping\n\n'+figure_audit()+'\n')
shutil.copy2(OUT/'figure_audit.md',DOWNLOADS/(PREFIX+'-figure-audit.md'))
shutil.copy2(OUT/'figure_audit.md',BUILD/'downloads'/(PREFIX+'-figure-audit.md'))
files={str(p.relative_to(OUT)):p for p in OUT.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt'}
for package in ('concordance_study','full_snv_concordance'):
    for p in (ROOT/'validation'/package).rglob('*'):
        if p.is_file() and p.suffix in ('.py','.md','.mdx','.json','.sh','.sbatch'):
            files['analysis_source/'+str(p.relative_to(ROOT))]=p
for p in (ROOT/'tests/unit').glob('test_conc*.py'):
    files['analysis_source/'+str(p.relative_to(ROOT))]=p
for name in ['validation/__init__.py','LICENSE']:
    files['analysis_source/'+name]=ROOT/name
archive(DOWNLOADS/(PREFIX+'.zip'),files)
with zipfile.ZipFile(DOWNLOADS/(PREFIX+'.zip')) as z:
    assert len(z.namelist())==len(set(z.namelist()))
    for line in z.read('SHA256SUMS.txt').decode().splitlines():
        expected,name=line.split('  ',1)
        assert hashlib.sha256(z.read(name)).hexdigest()==expected,name
    assert 'analysis_source/validation/concordance_study/concise_supplement.py' in z.namelist()
    assert 'full-snv-scoring-technical-report.pdf' in z.namelist()
    assert 'full-snv-scoring-supplement.pdf' in z.namelist()
(DOWNLOADS/(PREFIX+'-SHA256SUMS.txt')).write_text(''.join(f'{digest(p)}  {p.relative_to(DOWNLOADS)}\n' for p in sorted(DOWNLOADS.glob(PREFIX+'*')) if p.suffix in ('.html','.zip','.md')))
# These bytes are downloadable artifacts; generated pages and PDFs are unchanged.
for suffix in ('.zip','-SHA256SUMS.txt'):
    shutil.copy2(DOWNLOADS/(PREFIX+suffix),BUILD/'downloads'/(PREFIX+suffix))
receipt['archive_bytes']=(DOWNLOADS/(PREFIX+'.zip')).stat().st_size
receipt['archive_sha256']=digest(DOWNLOADS/(PREFIX+'.zip'))
receipt['archive_members_checked']=len(files)
receipt['archive_checksums_verified']=True
(EVIDENCE/'artifact-checks.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
