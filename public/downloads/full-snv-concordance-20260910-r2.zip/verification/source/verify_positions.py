"""Read retained maps and source VCFs to locate rare loss-position exceptions."""
import concurrent.futures
import csv
import hashlib
import json
from pathlib import Path

BASE=Path(__file__).resolve().parent.parent
OUT=Path(__file__).resolve().parent/'verification'

def inspect_map(path):
    m=json.loads(path.read_text())
    exceptions={e:m['aggregate']['dp'][e]['0.5']['eligible']-m['aggregate']['dp'][e]['0.5']['within']['0'] for e in ('AL','DL')}
    if not any(exceptions.values()):
        return None
    return dict(map=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),exceptions=exceptions,
                chunks=m['chunk_ids'],files=[c for c in m['verified_provenance']['chunks']])

paths=sorted((BASE/'production/A_rs10_genomewide/maps').glob('map-*.json'))
found=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    for i,r in enumerate(pool.map(inspect_map,paths),1):
        if r:
            found.append(r); print('map exceptions',r['map'],r['exceptions'],flush=True)
        if i%100==0:print('maps checked',i,flush=True)
(OUT/'position_exception_maps.json').write_text(json.dumps(dict(maps_checked=len(paths),maps=found),indent=2)+'\n')

def read_annotations(value):
    result={}
    for s in value.split(','):
        f=s.split('|')
        if len(f)==10 and all(x!='.' for x in f[2:]):
            result.setdefault((f[0],f[1]),set()).add(tuple(f[2:]))
    return result

records=[]
for m in found:
    for c in m['files']:
        v=next(v for v in c['vcfs'] if v['role']=='prediction')
        path=Path(v['path'])
        raw=path.read_bytes()
        if hashlib.sha256(raw).hexdigest()!=v['file_sha256']:
            raise ValueError(f'Prediction no longer matches frozen receipt: {path}')
        for line in raw.decode().splitlines():
            if line.startswith('#'):continue
            fields=line.split('\t')
            info=dict(x.split('=',1) for x in fields[7].split(';') if '=' in x)
            left,right=read_annotations(info.get('SpliceAI','')),read_annotations(info.get('OpenSpliceAI',''))
            for key in left.keys() & right.keys():
                if len(left[key])!=1 or len(right[key])!=1:continue
                l,r=next(iter(left[key])),next(iter(right[key]))
                for event,i in [('AL',1),('DL',3)]:
                    if float(l[i])>=.5 and float(r[i])>=.5 and int(l[i+4])!=int(r[i+4]):
                        records.append(dict(chrom=fields[0],pos=int(fields[1]),ref=fields[3],alt=key[0],gene=key[1],event=event,
                                            spliceai_score=float(l[i]),openspliceai_score=float(r[i]),spliceai_dp=int(l[i+4]),openspliceai_dp=int(r[i+4]),
                                            chunk=c['chunk_id'],source=str(path),file_sha256=v['file_sha256']))
    print('VCFs inspected for',m['map'],'candidate records',len(records),flush=True)
# Repeated VCF rows are collapsed by identical record values.
unique={tuple(r[k] for k in ('chrom','pos','ref','alt','gene','event','spliceai_score','openspliceai_score','spliceai_dp','openspliceai_dp')):r for r in records}
records=list(unique.values())
if records:
    with (OUT/'position_exception_records.csv').open('w') as h:
        w=csv.DictWriter(h,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
print('final exceptions',json.dumps(records,indent=2),flush=True)
