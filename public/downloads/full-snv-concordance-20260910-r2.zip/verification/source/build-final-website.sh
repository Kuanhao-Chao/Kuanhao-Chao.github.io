#!/usr/bin/env bash
set -euo pipefail
SNV_STUDY=/data/ssalzbe1/khchao/OpenSpliceAI/results/full_snv_concordance/study_20260908_depth
SNV_REV="$SNV_STUDY/revision_20260910_r2"
SNV_EVIDENCE="$SNV_REV/verification"
SNV_STAGE=$(mktemp -d "${TMPDIR:-/tmp}/snv-concise-${SLURM_JOB_ID:-local}-XXXXXX")
printf '%s\n' "$SNV_STAGE" > "$SNV_EVIDENCE/stage-path.txt"
tar -xf "$SNV_STUDY/toolchain/node22.tar.xz" -C "$SNV_STAGE"
mkdir "$SNV_STAGE/website"
tar -C "$SNV_STUDY/website-release" --exclude=./.git --exclude=./dist --exclude=./.astro -cf - . | tar -C "$SNV_STAGE/website" -xf -
export PATH="$SNV_STAGE/node-v22.23.2-linux-x64/bin:/usr/bin:/bin"
export PLAYWRIGHT_BROWSERS_PATH=/home/kchao10/.cache/ms-playwright
export CUDA_VISIBLE_DEVICES=''
export SNV_RELEASE_ID=20260910-r2
export SNV_REVIEW_EVIDENCE="$SNV_EVIDENCE"
export SNV_REVIEW_DIST="$SNV_STAGE/website/dist"
cd "$SNV_STAGE/website"
printf 'gate\tstatus\tutc\n' > "$SNV_EVIDENCE/website-gates.tsv"
run_gate() {
  local name="$1"
  shift
  printf '%s\trunning\t%s\n' "$name" "$(date -u +%FT%TZ)" >> "$SNV_EVIDENCE/website-gates.tsv"
  if "$@" > "$SNV_EVIDENCE/$name.log" 2>&1; then
    printf '%s\tpassed\t%s\n' "$name" "$(date -u +%FT%TZ)" >> "$SNV_EVIDENCE/website-gates.tsv"
  else
    local status=$?
    printf '%s\tfailed:%s\t%s\n' "$name" "$status" "$(date -u +%FT%TZ)" >> "$SNV_EVIDENCE/website-gates.tsv"
    return "$status"
  fi
}
run_gate website-check npm run check
if [[ "${1:-}" != --reuse-tests ]]; then
  run_gate website-tests npm test -- --maxWorkers=4 --testTimeout=300000
else
  test -s "$SNV_EVIDENCE/website-tests.log"
  printf 'website-tests\treused-prior-passing-suite\t%s\n' "$(date -u +%FT%TZ)" >> "$SNV_EVIDENCE/website-gates.tsv"
fi
run_gate website-build npm run build
/home/kchao10/miniconda3/envs/pytorch_cuda/bin/python "$SNV_REV/copy_build.py" dist "$SNV_REV/build-${SLURM_JOB_ID:-local}" > "$SNV_EVIDENCE/build-copy.json"
printf '%s\n' "$SNV_REV/build-${SLURM_JOB_ID:-local}" > "$SNV_EVIDENCE/build-path.txt"
for audit in indexing links refs:offline security; do
  run_gate "website-audit-${audit//:/-}" npm run "audit:$audit"
done
run_gate report-browser-review node scripts/review-snv-revision.mjs
printf 'all\tpassed\t%s\n' "$(date -u +%FT%TZ)" >> "$SNV_EVIDENCE/website-gates.tsv"

cd /data/ssalzbe1/khchao/OpenSpliceAI
/home/kchao10/miniconda3/envs/pytorch_cuda/bin/python "$SNV_REV/finalize_outputs.py" > "$SNV_EVIDENCE/artifact-checks.log" 2>&1
