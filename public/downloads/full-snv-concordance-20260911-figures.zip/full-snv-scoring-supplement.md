# Supplement: genome-wide OpenSpliceAI and SpliceAI comparison

## Abstract

We describe the scoring collection, annotation pairing, masking, and statistical summaries used to compare OpenSpliceAI with SpliceAI. Supporting analyses examine score differences, threshold transfer, output precision, annotation context, selected positions, and variation across genes and genomic blocks. All results use the same dated scientific snapshot as the main report; inference progress is documented separately.



This supplement accompanies the [main report](/reports/full-snv-scoring-technical-report/).
AG, AL, DG and DL denote acceptor gain, acceptor loss, donor gain and donor loss, respectively.
MAX is the largest of those four scores. Scientific results use the September 9 snapshot;
separately dated progress observations do not change the analyzed populations.

## Coverage and counting units

<figure><img src="figures/supp01_coverage.png" alt="Source records, variant groups and paired gene annotations have different denominators." /><figcaption>Figure S1. Counting units and pairing coverage. Counts refer to the primary rs10 comparison. VCF rows, distinct variant groups and variant–gene annotations are different units; these rows are not successive stages of a decreasing funnel. Pairing excludes missing or conflicting predictions. Counts for each model use its name explicitly. Coverage remains provisional.</figcaption></figure>

## Secondary event comparisons

<figure><img src="figures/supp02_tails.png" alt="Signed score-difference tails by event." /><figcaption>Figure S2. The direction of large score differences. Tail probabilities distinguish OpenSpliceAI exceeding SpliceAI from the reverse. The right panel compares these directions. Difference magnitudes use histogram centers and estimates are approximate. This supports, rather than replaces, the event-wise score and call comparisons.</figcaption></figure>

<figure><img src="figures/supp03_threshold_transfer.png" alt="Per-event cutoffs selected by call-volume matching or comparator MCC." /><figcaption>Figure S3. Matching call volume does not ensure matching membership. Every configured SpliceAI cutoff is shown. Candidate OpenSpliceAI cutoffs lie on the histogram grid and exclude the unresolved endpoint at one. MCC is agreement with SpliceAI; neither objective optimizes experimental accuracy.</figcaption></figure>

<figure><img src="figures/supp04_precision.png" alt="Exact score agreement after matching output precision and differences beyond the rounding allowance." /><figcaption>Figure S4. Score agreement under a rounding allowance. SpliceAI reports two decimal places and OpenSpliceAI five. Left, exact matches before and after rounding OpenSpliceAI to two decimals. Right, mean(max(|OpenSpliceAI − SpliceAI| − 0.005, 0)) divided by the original mean absolute difference. This is a residual-error share, not a fraction of discordant variants or an estimate of error caused by rounding. The 0.005 allowance is an operational sensitivity analysis; it does not reconstruct either model’s unrounded scores. Shared zeros remain in the denominator.</figcaption></figure>

<figure><img src="figures/supp05_dominant_event.png" alt="Row-normalized dominant-event transitions, retaining ties and all-zero annotations." /><figcaption>Figure S5. Dominant-event labels and their denominators. Each row is normalized by its displayed SpliceAI-category count. TIE denotes a tied nonzero maximum and NONE all-zero scores. Unlabelled cells have proportions below 0.005, not necessarily zero; displayed rounding can prevent row labels summing to one. Exact counts and proportions are supplied in figure_data/dominant_row_proportions.csv. Dominant labels compress four nonexclusive scores.</figcaption></figure>

## Context and selected positions

<figure><img src="figures/supp06_site_distributions.png" alt="Event-score survival distributions near and far from internal boundaries, including MAX." /><figcaption>Figure S6. Score distributions near and far from internal boundaries. Histogram survival curves show the fraction at or above each lower bin edge, using width 0.005. All panels share the same logarithmic rate scale and include MAX as a summary. The near population contains 5,431,412 annotations and the far population 2,805,642,585. Zero survival values cannot appear on the log axis; a point at cutoff zero alone does not establish a nonzero loss score. The far group is not a transcript-specific deep-intronic category.</figcaption></figure>

<figure><img src="figures/supp07_site_score_agreement.png" alt="Near and distant score distributions for gains and losses." /><figcaption>Figure S7. Conditional score distributions by boundary proximity. Points are histogram-derived conditional medians and intervals the central 50% of OpenSpliceAI scores for each SpliceAI bin. Empty bins remain gaps. Near and far populations contain 5,431,412 and 2,805,642,585 annotations, respectively; the number in each conditioning bin varies. These are distribution intervals, not confidence intervals or calibration against experimental outcomes. MAX is a summary of the four events.</figcaption></figure>

<figure><img src="figures/supp08_site_positions.png" alt="Exact and within-2-bp position agreement by event and annotation context at a score cutoff of 0.5." /><figcaption>Figure S8. Position agreement within jointly called distance groups. Exact and within-2-bp agreement require both event scores ≥0.5. All panels retain the same six variant-distance groups. A group without jointly called events has undefined agreement and is labelled No joint calls. Vertical labels give eligible counts and exact-position mismatches (miss). The complete table includes other cutoffs and tolerances. Rare AL and DL mismatches are preserved rather than hidden by rounded percentages.</figcaption></figure>

## Seed comparisons and genomic heterogeneity

<figure><img src="figures/supp09_seed_by_gene.png" alt="Gene-level method-to-seed mean absolute difference ratios." /><figcaption>Figure S9. Distribution of gene-level method-to-seed differences. Empirical cumulative distributions use the exact three-way intersection, with at least 1,000 paired observations per gene and positive, defined MAE ratios. All panels share log-axis limits. Legends give plotted gene counts; figure_data/seed_gene_summary.csv records exclusions, medians and fractions above one. Genes contribute equal weight to each curve. A small seed MAE can produce a large ratio; zero-denominator ratios are undefined.</figcaption></figure>

<figure><img src="figures/supp10_chromosome.png" alt="Mean signed MAX differences in all eligible 1-Mb blocks." /><figcaption>Figure S10. Regional variation in mean MAX differences. All 2,571 retained 1-Mb blocks with at least 10,000 paired annotations are shown across their full value range. Blocks are equally spaced within each chromosome; the horizontal scale is not proportional to genomic length. Point area increases with annotation count using an offset plus a scaled count. The dashed line is the primary annotation-weighted mean. MAX averages do not identify an event-specific regional mechanism.</figcaption></figure>

<figure><img src="figures/supp11_gene_divergence.png" alt="Gene-level MAX disagreement and selected high-divergence genes." /><figcaption>Figure S11. Distribution of gene-level mean MAX differences. Both panels contain 19,063 genes with at least 1,000 paired annotations. Point area increases linearly with annotation count after scaling. Up to twelve labels are selected in order of negative mean difference subject to spacing, so they are not strictly the twelve most negative genes. The scatter compares x=mean SpliceAI MAX with y=mean OpenSpliceAI MAX−x; the shared x term and bound y≥−x create mathematical coupling. The histogram shows the same gene differences and their median. Neither panel tests enrichment or establishes disease associations.</figcaption></figure>
