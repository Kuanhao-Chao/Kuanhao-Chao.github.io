# Full SNV concordance study — September 9, 2026

This release completes the CPU depth analysis of the frozen September 8 scoring snapshot.
All results are provisional. SpliceAI is the comparator, not experimental truth. Legacy score
files lack embedded model receipts; execution manifests do not establish their checkpoint identity.

The primary analysis covers 99,283 audited chunks and 3,334,708,099 exact-gene pairs. The three
matched comparisons share exactly 1,536,316,689 observations across 45,589 chunks. Both
production reductions and the independent validation windows completed. The independent
implementation passed 11,195 primary and 40,020 matched checks, including event moments,
exact counts, six stratum dimensions, joint histograms and predicted-position agreement.

## Files

- `study_facts.json`: the single fact base for the standalone and both website reports.
- `OpenSpliceAI_vs_SpliceAI_genome_wide.html`: self-contained reading copy. The
  `.artifact.html` sibling is an embeddable fragment for an artifact viewer. The hosted
  browser copy references ordinary PNG URLs to follow the website security policy.
- `figures/`: all 16 figures as PNG and vector PDF, with a caption index.
- `tables/seed_versus_method_strata.csv`: matched comparisons across genomic strata.
- Four companion arm archives: 103 per-arm CSV files, plus the shared-stratum CSV in the
  main study bundle (104 CSVs total).
- `verification/`: independent receipts, production contracts, scheduler accounting, frozen-code
  equivalence and the complete boundary-layout audit. Floating checks use relative 1e-9 and
  absolute 1e-10 tolerances; raw moment-sum differences can exceed the absolute tolerance.
- `execution/`: frozen source, pair lists, annotation, launch records and execution manifests.
- `analysis_source/`: reporting and current analysis source. The reducer boundary safeguard was
  strengthened after freezing; exhaustive production edge audits found no triggering layout.
- `SHA256SUMS.txt`: identities of every file in each archive. The separate download manifest
  identifies the archives and standalone HTML. Run `sha256sum -c SHA256SUMS.txt` after extraction.

Raw VCFs and multi-gigabyte map/reduce summaries remain on cluster storage; they are not
included in these downloads. Pair lists retain their original cluster paths and hashes. The
frozen execution manifests likewise retain original absolute paths. Re-running computation
requires the corresponding audited score files and a path-preserving or explicitly relocated setup.

## Regeneration

From the OpenSpliceAI repository, use Python with NumPy, matplotlib and Markdown installed:

```bash
python -m validation.concordance_study render-study \
  --runs-root results/full_snv_concordance/study_20260908_depth \
  --arm A_rs10_genomewide=production/A_rs10_genomewide:primary:99283 \
  --arm B_seeds_rs10_rs13=production/matched/B_seeds_rs10_rs13:seed:45589 \
  --arm C_rs10_matched=production/matched/C_rs10_matched:matched:45589 \
  --arm D_rs13_matched=production/matched/D_rs13_matched:matched:45589 \
  --primary A_rs10_genomewide --seed-arm B_seeds_rs10_rs13 \
  --model-arm C_rs10_matched --model-arm D_rs13_matched \
  --sites-file data/grch38_chr.txt \
  --study-meta results/full_snv_concordance/study_20260908_depth/study_meta.json \
  --template validation/concordance_study/templates/OpenSpliceAI_vs_SpliceAI_genome_wide.md \
  --output-dir results/full_snv_concordance/study_20260908_depth/publication

python -m validation.concordance_study.prepare_release \
  --study-dir results/full_snv_concordance/study_20260908_depth \
  --website-root /path/to/website-checkout
```

The release preparer resolves both MDX templates from the same facts, copies figures, regenerates
standalone documents, and creates size-limited archives with per-file checksums. Publishing also
requires both report slugs in the website sitemap/PDF allowlists and corresponding robots entries.
The website requires Node 22, `npm ci`, check, tests, build/PDF, indexing, links, reference/dataset,
ML curriculum and security audits. Deploy only after these gates and visual review pass.
