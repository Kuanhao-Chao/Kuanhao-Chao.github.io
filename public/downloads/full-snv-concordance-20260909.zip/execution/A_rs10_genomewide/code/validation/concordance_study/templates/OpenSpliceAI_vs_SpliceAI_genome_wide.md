<header class="masthead" markdown="1">
<p class="eyebrow">OpenSpliceAI validation study</p>

# Genome-wide concordance of OpenSpliceAI and SpliceAI variant delta scores

<p class="dek">A mask-, annotation- and distance-matched comparison of two splice-variant
predictors over essentially the whole human SNV space, and a measurement of how much of the
difference between them is simply the difference between two training runs.</p>

<p><span class="status">Provisional</span></p>

<dl class="meta">
<div><dt>Paired annotations</dt><dd>{{primary.coverage.paired_annotations|,d}}</dd></div>
<div><dt>Audited chunks</dt><dd>{{primary.chunks|,d}} of {{study.source_chunks|,d}}</dd></div>
<div><dt>Comparison arms</dt><dd>4</dd></div>
<div><dt>Generated</dt><dd>{{generated_at}}</dd></div>
<div><dt>Analysis code</dt><dd class="small">{{study.analysis_code_sha256}}</dd></div>
</dl>
</header>

{{study.campaign_status}} Every result below is provisional by the reducer's own contract.

[TOC]

## Abstract

We compare the delta scores produced by SpliceAI and by OpenSpliceAI over
essentially the whole human SNV space: {{primary.coverage.paired_annotations|,d}} exact-gene paired
annotations drawn from {{primary.chunks|,d}} audited chunks. Unlike previous comparisons in this
project, both sides are masked, both were scored against the same gene table with the same maximum
distance and flanking context, and the same reference assembly -- so the difference that remains is
the trained system, not the post-processing.

Agreement on the maximum delta score is **moderate**: Pearson
{{primary.agreement.MAX.pearson_r|.4f}}, Lin concordance {{primary.agreement.MAX.lin_ccc|.4f}}, and
a positive-class Jaccard at a 0.5 cutoff of {{primary.thresholds.MAX[0.5].jaccard|.4f}} -- of the
variants called by at least one system, only about half are called by both. Overall agreement at
that cutoff is {{primary.thresholds.MAX[0.5].overall_agreement|pct3}}, but this is an artefact of
the shared negative mass and should not be quoted.

The disagreement is **not uniform across events**. Loss scores agree closely (Pearson
{{primary.agreement.AL.pearson_r|.4f}} and {{primary.agreement.DL.pearson_r|.4f}}); gain scores do
not ({{primary.agreement.AG.pearson_r|.4f}} and {{primary.agreement.DG.pearson_r|.4f}}), and
OpenSpliceAI scores gains systematically lower. Measuring training-seed variation on an identical
chunk domain separates the two explanations: for losses, two independent implementations are almost
as interchangeable as two training seeds of one implementation (error ratios
{{seed_versus_model.events.AL.ratios.C_rs10_matched.mae|.2f}} and
{{seed_versus_model.events.DL.ratios.C_rs10_matched.mae|.2f}}); for gains the method gap is
{{seed_versus_model.events.AG.ratios.C_rs10_matched.mae|.2f}} to
{{seed_versus_model.events.DG.ratios.C_rs10_matched.mae|.2f}} times the seed gap. Output precision
explains exact-value disagreement but not magnitude and not calls.

Call behaviour crosses over with the threshold: OpenSpliceAI makes only
{{primary.thresholds.MAX[0.1].call_rate_ratio_right_over_left|.3f}} as many calls as SpliceAI at a
0.1 cutoff but {{primary.thresholds.MAX[0.8].call_rate_ratio_right_over_left|.3f}} times as many at
0.8, and chance-corrected agreement improves monotonically with the cutoff (kappa
{{primary.thresholds.MAX[0.1].kappa|.4f}} to {{primary.thresholds.MAX[0.8].kappa|.4f}}). Where both
systems call a variant, they agree about the affected position almost perfectly.

This is a concordance study against a comparator, not a truth set. It establishes where and how much
the two systems differ, and localises that difference to gain prediction. It cannot, and does not,
say which system is right.

## 1. Introduction

SpliceAI (Jaganathan *et al.*, 2019) predicts, for a given variant, four delta
scores: the change in the probability that a position is used as a splice
acceptor or donor, decomposed into gain and loss. OpenSpliceAI is a PyTorch
reimplementation and retraining of that architecture. The two therefore produce
quantities with the same name, the same range and the same intended meaning,
which raises an empirical question that a reimplementation paper has to answer:
**on the same variants, scored the same way, do the two systems say the same
thing -- and where they differ, how do they differ?**

An earlier comparison in this project reached only a partial answer. It rested on
452,053 variants drawn from the 5-prime ends of scored chunks, and -- decisively --
compared an *unmasked* OpenSpliceAI to a *masked* SpliceAI. Masking suppresses
gain scores at annotated splice sites and loss scores away from them, so it acts
directly on the axis along which the two systems most disagreed. That analysis
correctly flagged the mismatch as load-bearing and declined to attribute the gap
to the model.

This study removes that confound. Both sides are masked, both use the same
scoring annotation, the same maximum distance and the same reference assembly,
and the analysis covers {{primary.coverage.paired_annotations|,d}} exact-gene
paired annotations drawn from {{primary.chunks|,d}} audited chunks -- roughly
{{primary.coverage.source_rows|,d}} source variant records. What remains between
the two systems is the model itself, the published output precision, and gene
coverage.

A second question follows immediately, and could not be asked at all before: a
difference between two trained neural networks is only interesting if it is
larger than the difference between two training runs of the *same* network. This
study measures both, on identical data.

### What this study can and cannot establish

It is a **concordance** study. It characterises numerical, event, positional and
regional agreement between two score collections. SpliceAI is the comparator, not
ground truth. No experimentally validated splicing outcome, functional assay or
clinical label enters the analysis, so **nothing here ranks the two predictors on
biological accuracy**, and no statement of the form "X is more correct than Y"
is supportable from these data. Where the two disagree, this report says which
one scores higher and by how much, and stops there.

## 2. Methods

### 2.1 Comparison design

{{table:runs_overview}}

Arm **A** is the primary genome-wide comparison. Arms **B**, **C** and **D**
share a single chunk domain of {{arms.B_seeds_rs10_rs13.chunks|,d}} chunks -- the
intersection of the chunks scored by both OpenSpliceAI seeds -- so that
training-seed disagreement and method disagreement are measured on exactly the
same variants, genes and statistics. That restricted domain is
{{study.rs13_genomic_extent}}: a contiguous genomic region, **not** a random
subsample of the genome, and section 9 tests directly whether conclusions drawn
on it carry genome-wide.

### 2.2 Inputs and scoring

The variant collection is {{study.source_collection}}: {{study.source_chunks|,d}}
headered GRCh38 VCF chunks whose `INFO` field carries the published SpliceAI
annotation `ALLELE|SYMBOL|DS_AG|DS_AL|DS_DG|DS_DL|DP_AG|DP_AL|DP_DG|DP_DL`.
Those scores come from {{study.spliceai_model}} and are published at
{{study.source_precision_dp}} decimal places.

OpenSpliceAI {{study.openspliceai_version}} re-scored every record in place,
preserving the source row and adding a second annotation in the same format:

```
{{study.scoring_command}}
```

The two sides are matched on the properties that would otherwise confound the
comparison:

| Property | SpliceAI | OpenSpliceAI |
|:---|:---|:---|
| Masking | `M=1` | `M=1` |
| Maximum distance | {{study.distance|d}} nt | {{study.distance|d}} nt |
| Flanking context | {{study.flanking_size|,d}} nt | {{study.flanking_size|,d}} nt |
| Scoring annotation | {{study.scoring_annotation}} | {{study.scoring_annotation}} |
| Reference | GRCh38 | {{study.reference_assembly}} |
| Output precision | {{study.source_precision_dp|d}} dp | {{study.openspliceai_precision_dp|d}} dp |
| Model | {{study.spliceai_model}} | {{study.openspliceai_model}} |

Note the asymmetry that remains by construction and cannot be removed here:
SpliceAI's published scores are an **ensemble of five models**, while each
OpenSpliceAI arm is a **single checkpoint**. Ensembling suppresses variance, so
part of any dispersion difference is attributable to that alone. This is one
reason the seed contrast in section 8 matters.

Scoring ran with a pinned deterministic runtime
({{study.deterministic_runtime}}).

### 2.3 Analysis unit

The unit is the exact tuple `(CHROM, POS, REF, ALT, gene)`, not a VCF row. A
source row may carry several annotations for overlapping genes, and a prediction
may repeat an identical multi-gene annotation on each row. The parser therefore
deduplicates identical repeats, counts and **excludes** conflicting values for
the same method and gene, and pairs only on an exact allele and an exact gene
symbol. An annotation present on one side and absent on the other stays in the
coverage denominator and is never silently treated as a zero score.

A secondary, annotation-agnostic view collapses each side independently to its
event-wise maximum across genes. It is reported as a sensitivity check only: it
can pair signal that the two systems assigned to *different* genes, so it must
not be read as gene-level concordance.

### 2.4 Statistics

For each of the four events and their maximum, the reducer accumulates exact
additive sums and counts, from which it derives bias, mean absolute error, root
mean squared error, Pearson correlation, Lin's concordance correlation
coefficient, exact-match and practical-equivalence rates, and complete
two-by-two call tables at 0.1, 0.2, 0.5 and 0.8 with Jaccard, Dice, Cohen's
kappa and the Matthews correlation. Rank and distributional statistics
(Spearman, Kolmogorov-Smirnov, Wasserstein-1, Jensen-Shannon) are computed from
100-bin histograms and are **approximate**; they are marked with an asterisk
throughout.

At this sample size a p-value is not informative -- with
{{primary.coverage.paired_annotations|,d}} paired observations essentially any
non-zero difference is "significant" -- so the presentation is effect size with
its denominator. Uncertainty is expressed instead as deterministic cluster
bootstraps over genes and over 1-Mb blocks, which are sensitivity intervals
under a dependence assumption, not sampling intervals over independent
biological units.

### 2.5 Provenance and completeness

Every chunk was deep-audited on {{study.audit_date}}: byte size, nanosecond
mtime, record count, a canonical record digest, and raw SHA-256 of both input and
output. Each mapper task re-verifies those hashes before reading a file and
re-checks that nothing changed underneath it. Reducers fail closed on a missing
or duplicated task, a duplicated chunk, a changed pair list, mixed run labels or
mixed mapper configurations.

{{table:provenance}}

No arm can be labelled **final**: that status requires the pair list to contain
exactly chunk IDs 1 through {{study.source_chunks|,d}}, and scoring is
incomplete. Every result below is therefore **provisional** by contract, and the
document renderer refuses to describe it otherwise. Separately, all outputs
predate the scorer's cryptographic receipt feature and are classed
`legacy_unprovenanced`: they are structurally audited and hash-pinned, but their
original model identity is not cryptographically provable.

## 3. Coverage and completeness

{{table:coverage}}

<figure><img src="figures/f01_coverage.png" alt="Coverage attrition from source rows to paired annotations"></figure>

The comparison is close to complete on its own terms. Of
{{primary.coverage.left_valid_annotations|,d}} valid SpliceAI annotations,
{{primary.coverage.paired_annotations|,d}} --
{{primary.coverage_rates.paired_share_of_spliceai_annotations|pct2}} -- found an OpenSpliceAI
annotation for the same allele and the same gene, and that set is the denominator of every
paired statistic below. Across
{{primary.coverage.annotation_observations|,d}} annotation observations, **not one was
malformed**, and disagreement within a single method about a single gene is vanishingly rare:
{{primary.coverage.left_conflicts|,d}} conflicting SpliceAI values and
{{primary.coverage.right_conflicts|,d}} conflicting OpenSpliceAI values, which are counted and
excluded rather than arbitrated.

The unpaired remainder is structural, not a model failure.
{{primary.coverage.left_only_annotations|,d}} SpliceAI annotations name a gene that OpenSpliceAI
was never asked about: the published SpliceAI collection contains gene symbols that are absent
from the gene table both sides were scored against (`CAPN8`, on chromosome 1, is one such gene,
and whole chunks in such regions receive no OpenSpliceAI value at all). The reverse case is
negligible at {{primary.coverage.right_only_annotations|,d}} annotations. A further
{{primary.coverage.duplicate_annotations|,d}} annotations were identical repetitions -- the
scorer emits the same multi-gene annotation on each overlapping source row -- and were collapsed
rather than double-counted. Finally, {{primary.finality.excluded_incomplete_edge_fragments|,d}}
variant groups sat against one of the {{primary.finality.unselected_chunk_count|,d}} chunks that
have not been scored, and were dropped rather than joined across the gap.

The practical consequence is that coverage is not a limitation of this analysis. The paired set
is large enough, and clean enough, that everything below is limited by interpretation rather
than by data quality.

## 4. Continuous agreement

{{table:agreement}}

<small>\* Spearman is computed from binned midranks and is approximate.</small>

{{table:equivalence}}

<figure><img src="figures/f02_joint_density.png" alt="Joint density of paired delta scores"></figure>

<figure><img src="figures/f03_difference_distributions.png" alt="Signed score differences per event"></figure>

Two things in this table matter, and the second is the reason the study was run.

**Agreement on the maximum delta score is moderate, not tight.** Pearson correlation is
{{primary.agreement.MAX.pearson_r|.4f}} and Lin's concordance -- which, unlike Pearson, penalises
a shift as well as a scale change -- is {{primary.agreement.MAX.lin_ccc|.4f}}. Mean absolute
difference is {{primary.agreement.MAX.mae|.5f}} on a 0-1 scale, and the mean signed difference
(OpenSpliceAI minus SpliceAI) is {{primary.agreement.MAX.bias|+.5f}} -- OpenSpliceAI scores lower
on average. Those averages are small because
most variants are near zero in both systems; section 4.1 shows what they conceal.

**Losses and gains behave completely differently, and not only in degree.** Acceptor and donor
*loss* scores agree closely -- Pearson {{primary.agreement.AL.pearson_r|.4f}} and
{{primary.agreement.DL.pearson_r|.4f}}, with Lin concordance essentially as high, and the two
systems return an identical value for {{primary.agreement.AL.exact_match_rate|pct2}} and
{{primary.agreement.DL.exact_match_rate|pct2}} of variants respectively. Acceptor and donor
*gain* scores agree far less: Pearson {{primary.agreement.AG.pearson_r|.4f}} and
{{primary.agreement.DG.pearson_r|.4f}}. The **direction** of the discrepancy also flips: on
losses OpenSpliceAI scores marginally *higher* than SpliceAI
({{primary.agreement.AL.bias|+.5f}} and {{primary.agreement.DL.bias|+.5f}}), while on gains it
scores materially *lower* ({{primary.agreement.AG.bias|+.5f}} and
{{primary.agreement.DG.bias|+.5f}}).

This loss-versus-gain asymmetry was visible in the earlier {{study.prior_analysis_n|,d}}-variant
analysis, but that analysis could not attribute it, because it compared an unmasked OpenSpliceAI against a masked
SpliceAI and masking acts on exactly the gain side. Here both sides are masked, both were scored
against the same gene table, with the same maximum distance and the same flanking context. **The
asymmetry survives that control**, so it is a property of the two trained systems rather than an
artefact of how their outputs were post-processed. What it is *not* is evidence about which
system is closer to biological truth: nothing in this study can adjudicate that.

### 4.1 Where the disagreement lives

Genome-wide averages are dominated by variants both systems score at or near
zero. Restricting to variants where at least one system reports signal shows what
the averages conceal:

{{table:signal_subsets}}

Read the correlation column of that table carefully, because it invites a
serious misreading. Pearson correlation falls monotonically as the subset narrows -- from
{{primary.agreement.MAX.pearson_r|.4f}} over all pairs to
{{primary.signal_subsets.MAX[either_ge_0.5].pearson_r|.4f}} on variants where either system
reaches 0.5, and to {{primary.signal_subsets.MAX[either_ge_0.8].pearson_r|.4f}} where either
reaches 0.8. That decline is **overwhelmingly a range-restriction and selection effect, not a
discovery that the systems disagree more when confident**. Selecting on the *union* of high
scores deliberately enriches for pairs where one system is high and the other is not, and
simultaneously compresses the range within which a correlation can be measured; both push Pearson
toward zero regardless of how well the systems agree.

The interpretable quantities on these subsets are the location and error columns. On the
{{primary.signal_subsets.MAX[either_ge_0.5].n|,d}} variants where either system reaches 0.5, the
mean signed difference is {{primary.signal_subsets.MAX[either_ge_0.5].bias|+.5f}} and the mean
absolute difference is {{primary.signal_subsets.MAX[either_ge_0.5].mae|.5f}} -- that is, among
decision-relevant variants the typical disagreement is roughly a quarter of the score range,
which is substantial. At the strictest subset the mean signed difference is essentially zero
({{primary.signal_subsets.MAX[either_ge_0.8].bias|+.5f}}), so the systematic gap seen genome-wide
does not persist among the variants both systems score most confidently.

The subset sizes are themselves informative: only
{{primary.signal_subsets.MAX[either_gt_0].n|,d}} paired annotations -- one in six -- are non-zero
in either system, and only {{primary.signal_subsets.MAX[either_ge_0.5].n|,d}} reach 0.5 in
either. Any statistic computed over all pairs is dominated by agreed silence.

## 5. Output precision

SpliceAI's published scores carry {{study.source_precision_dp|d}} decimals;
OpenSpliceAI's carry {{study.openspliceai_precision_dp|d}}. Two scores differing
by less than 0.005 are indistinguishable from that rounding, so some apparent
disagreement is arithmetic rather than biology.

{{table:quantization}}

<figure><img src="figures/f11_quantization.png" alt="Effect of matching output precision"></figure>

Output precision explains a great deal about *exact equality* and
almost nothing about *magnitude*. Rounding OpenSpliceAI to SpliceAI's two-decimal grid raises the
exact-match rate on the maximum score from
{{primary.quantization.MAX.raw_exact_match_rate|pct2}} to
{{primary.quantization.MAX.rounded_exact_match_rate|pct2}}, a gain of
{{primary.quantization.MAX.exact_match_gain|pct2}}. Mean absolute error, meanwhile, moves by
{{primary.quantization.MAX.mae_change|.2e}} -- nothing. Put differently,
{{primary.quantization.MAX.share_of_mae_beyond_quantization|pct1}} of the mean absolute
difference survives discarding every discrepancy small enough to be attributable to the +/-0.005
rounding band, and the same is true event by event.

The distinction matters for threshold calls too. One might expect SpliceAI's coarser grid to
inflate its positive counts, since a true 0.096 is published as 0.10 and clears a 0.1 cutoff that
the five-decimal value would miss. Rounding OpenSpliceAI onto the same grid moves the call-rate
ratio at 0.1 only from
{{primary.thresholds.MAX[0.1].call_rate_ratio_right_over_left|.3f}} to
{{primary.right_rounded_2dp_thresholds.MAX[0.1].call_rate_ratio_right_over_left|.3f}}, and
Cohen's kappa by less than a thousandth. **The threshold behaviour described in the next section
is therefore a property of the models, not of how many decimals they print.**

## 6. Threshold agreement and operating-point transfer

Delta scores are used through a cutoff. The relevant question is not whether the
scores are numerically close but whether the two systems **flag the same
variants**.

{{table:thresholds_max}}

Overall agreement is reported for completeness only, and should not be quoted on
its own: with the overwhelming majority of variants below any threshold in both
systems, agreement is near-certain by construction. Jaccard, kappa and the
Matthews correlation are the informative columns.

{{table:thresholds_by_event}}

<figure><img src="figures/f04_threshold_agreement.png" alt="Threshold agreement by event"></figure>

The headline agreement figure is the least useful number here. At a 0.5
cutoff the two systems agree on
{{primary.thresholds.MAX[0.5].overall_agreement|pct3}} of variants -- but
{{primary.thresholds.MAX[0.5].both_negative|,d}} of the
{{primary.thresholds.MAX[0.5].n|,d}} pairs are below the cutoff in *both* systems, so near-total
agreement is guaranteed by the shared silence rather than earned. The chance-corrected view is
much more sober: Cohen's kappa {{primary.thresholds.MAX[0.5].kappa|.4f}}, Matthews correlation
{{primary.thresholds.MAX[0.5].mcc|.4f}}, and a positive-class Jaccard of
{{primary.thresholds.MAX[0.5].jaccard|.4f}} -- meaning that of all variants called by at least one
system at 0.5, only about half are called by both.

The most striking pattern is in the call-rate ratio, and it is a **crossover**. At a 0.1 cutoff
OpenSpliceAI makes only
{{primary.thresholds.MAX[0.1].call_rate_ratio_right_over_left|.3f}} as many calls as SpliceAI
({{primary.thresholds.MAX[0.1].both_positive|,d}} shared, against
{{primary.thresholds.MAX[0.1].left_only|,d}} called by SpliceAI alone and only
{{primary.thresholds.MAX[0.1].right_only|,d}} by OpenSpliceAI alone). That ratio rises through
{{primary.thresholds.MAX[0.2].call_rate_ratio_right_over_left|.3f}} at 0.2 and
{{primary.thresholds.MAX[0.5].call_rate_ratio_right_over_left|.3f}} at 0.5, and **reverses** at
0.8, where OpenSpliceAI makes {{primary.thresholds.MAX[0.8].call_rate_ratio_right_over_left|.3f}}
times as many calls as SpliceAI. So "OpenSpliceAI is the more conservative caller" is true only
at permissive cutoffs; at stringent ones it is marginally the more liberal of the two. Agreement
improves monotonically as the cutoff rises (kappa
{{primary.thresholds.MAX[0.1].kappa|.4f}} to {{primary.thresholds.MAX[0.8].kappa|.4f}}), which is
the reassuring part: the two systems converge exactly where a clinical or research pipeline would
be acting on the score.

Broken out by event, the same asymmetry as section 4 appears in the calls themselves.

### 6.1 Which OpenSpliceAI cutoff corresponds to a SpliceAI cutoff?

Anyone moving an existing SpliceAI threshold onto OpenSpliceAI needs to know
what the equivalent cutoff is. Two defensible answers, with different uses: the
**rate-matched** cutoff makes OpenSpliceAI flag as many variants as SpliceAI
does, preserving review workload; the **agreement-optimal** cutoff maximises the
Matthews correlation against SpliceAI's own call set, preserving *which*
variants are flagged.

{{table:operating_point}}

<figure><img src="figures/f05_operating_point_transfer.png" alt="Agreement as the OpenSpliceAI cutoff varies"></figure>

Three findings, in decreasing order of practical weight.

First, **keeping the same number is a defensible default**. At a SpliceAI cutoff of 0.5,
transferring the threshold unchanged yields a Matthews correlation of
{{primary.operating_point[0.5].identical_cutoff.mcc|.4f}}, while the best achievable value over
every cutoff on the grid is {{primary.operating_point[0.5].agreement_optimal.mcc|.4f}} at
OpenSpliceAI >= {{primary.operating_point[0.5].agreement_optimal.right_cutoff|.2f}}. Re-tuning
buys very little.

Second, if a pipeline is tuned for agreement rather than volume, the optimal OpenSpliceAI cutoff
is **higher** than SpliceAI's at the stringent end --
{{primary.operating_point[0.5].agreement_optimal.right_cutoff|.2f}} for SpliceAI's 0.5 and
{{primary.operating_point[0.8].agreement_optimal.right_cutoff|.2f}} for its 0.8 -- and lower at
the permissive end ({{primary.operating_point[0.1].agreement_optimal.right_cutoff|.2f}} for 0.1).

Third, matching *workload* is a different question with a different answer, and at low cutoffs a
very different one. Reproducing the number of variants SpliceAI flags at 0.1 requires dropping
the OpenSpliceAI cutoff to
{{primary.operating_point[0.1].rate_matched.right_cutoff|.2f}}, which raises the shared-call
Jaccard slightly ({{primary.operating_point[0.1].identical_cutoff.jaccard|.4f}} to
{{primary.operating_point[0.1].rate_matched.jaccard|.4f}}) while leaving Matthews correlation
essentially unchanged. Anyone who needs the same review burden should rate-match; anyone who
needs the same variants should not.

## 7. Event identity and predicted position

Agreement on a score is not agreement on a mechanism. Two further questions:
does each system consider the same *event* dominant, and when both call a
variant, do they point at the same *position*?

{{table:dominant}}

<figure><img src="figures/f06_dominant_event.png" alt="Dominant-event agreement"></figure>

{{table:dp_agreement}}

<figure><img src="figures/f07_dp_agreement.png" alt="Predicted-position agreement by tolerance"></figure>

**Event identity.** Overall, the two systems nominate the same dominant
event for {{primary.dominant.summary.overall_exact_rate|pct2}} of paired variants, but that
figure is again carried by agreed silence. Within each of SpliceAI's categories the pattern
mirrors section 4 exactly: where SpliceAI's dominant event is a *loss*, OpenSpliceAI agrees for
the large majority of variants, whereas where SpliceAI's dominant event is a *gain*, agreement is
markedly weaker and roughly a fifth of those variants receive no non-zero score at all from
OpenSpliceAI. The disagreement is therefore not a matter of the two systems swapping acceptor for
donor -- cross-event confusion is small -- but of OpenSpliceAI declining to call gains that
SpliceAI calls.

**Predicted position.** Among variants both systems call at 0.5, positional agreement is
essentially perfect for losses and very high for gains. That contrast is mechanical rather than
mysterious: under masking, a loss score is only reported at a position that the shared gene
annotation already declares to be a splice site, so both systems are constrained to the same
coordinate. Gains are unconstrained, and there the two systems still place the predicted site at
exactly the same base for the overwhelming majority of jointly called variants. Where the systems
agree that a variant matters, they agree about *where* it matters.

## 8. Training-seed reproducibility, and how it compares with the method gap

Arms B, C and D share one chunk domain, so the following three quantities are
directly comparable: the disagreement between two OpenSpliceAI checkpoints that
differ **only** in their random training seed, and the disagreement between each
of those checkpoints and SpliceAI.

{{table:seed_versus_model}}

<figure><img src="figures/f10_seed_versus_model.png" alt="Training-seed disagreement against method disagreement"></figure>

{{table:seed_versus_model_events}}

This is the most informative table in the report, and it says something the aggregate row does not.

**Overall, the method gap is real and clearly larger than training noise, but of the same order.**
Two OpenSpliceAI checkpoints differing only in their random seed disagree by
{{seed_versus_model.seed.mae|.5f}} mean absolute error, with Pearson
{{seed_versus_model.seed.pearson_r|.4f}}. SpliceAI against either of those checkpoints disagrees by
about {{seed_versus_model.models.C_rs10_matched.mae|.5f}}, with Pearson
{{seed_versus_model.models.C_rs10_matched.pearson_r|.4f}}. The method gap is
{{seed_versus_model.error_ratios_model_over_seed.C_rs10_matched.mae|.2f}} times the seed gap in
mean absolute error and only
{{seed_versus_model.error_ratios_model_over_seed.C_rs10_matched.rmse|.2f}} times in RMSE. So
switching from SpliceAI to OpenSpliceAI is a bigger perturbation than retraining OpenSpliceAI with a
different seed -- but not by an order of magnitude. A meaningful fraction of what looks like a
difference between two *implementations* is the size of difference one gets from two *runs* of one
implementation.

**Event by event, that summary breaks apart completely.** On acceptor and donor *loss*, the method
gap is barely distinguishable from the seed gap: correlations of
{{seed_versus_model.events.AL.models.C_rs10_matched.pearson_r|.4f}} and
{{seed_versus_model.events.DL.models.C_rs10_matched.pearson_r|.4f}} between the two systems, against
{{seed_versus_model.events.AL.seed.pearson_r|.4f}} and
{{seed_versus_model.events.DL.seed.pearson_r|.4f}} between two seeds of one system, with error
ratios of {{seed_versus_model.events.AL.ratios.C_rs10_matched.mae|.2f}} and
{{seed_versus_model.events.DL.ratios.C_rs10_matched.mae|.2f}}. **For loss prediction, a different
implementation is very nearly as interchangeable as a different training seed.** On acceptor and
donor *gain* the picture inverts: error ratios of
{{seed_versus_model.events.AG.ratios.C_rs10_matched.mae|.2f}} and
{{seed_versus_model.events.DG.ratios.C_rs10_matched.mae|.2f}}, and correlations that fall from
{{seed_versus_model.events.AG.seed.pearson_r|.4f}} and
{{seed_versus_model.events.DG.seed.pearson_r|.4f}} between seeds to
{{seed_versus_model.events.AG.models.C_rs10_matched.pearson_r|.4f}} and
{{seed_versus_model.events.DG.models.C_rs10_matched.pearson_r|.4f}} between systems.

Taken with section 4, this localises the entire OpenSpliceAI-versus-SpliceAI difference. It is not
a diffuse numerical drift across all four scores, and it is not simply training-run variance: it is
a specific, reproducible disagreement about **gains**, which survives a control that matches the
mask, the annotation, the distance and the genomic domain, and which is three to four times larger
than what re-training the same architecture produces.

The two seeds also differ slightly in how closely they track SpliceAI -- rs13 agrees marginally
better than rs10 on every summary statistic -- which is a useful reminder that a single checkpoint
is one draw, and that SpliceAI's published scores average five of them.

## 9. Heterogeneity across the genome

{{table:stratum_dispersion}}

{{table:chromosomes}}

<figure><img src="figures/f08_chromosome.png" alt="Per-chromosome bias and error"></figure>

{{table:substitutions}}

{{table:top_genes}}

<figure><img src="figures/f09_gene_divergence.png" alt="Most divergent genes"></figure>

{{table:bootstrap}}

Two observations, one reassuring and one worth following up.

The reassuring one: **the relationship between the two systems is remarkably uniform across the
genome.** Per-chromosome Pearson correlation varies only within a narrow band around the
genome-wide value, and the gene- and 1-Mb-block cluster bootstraps put tight intervals around
every headline statistic -- the gene-clustered 95% interval for the maximum-score Pearson
correlation is
[{{primary.bootstrap.dimensions.gene.metrics.pearson_r.lower|.4f}},
{{primary.bootstrap.dimensions.gene.metrics.pearson_r.upper|.4f}}] around an estimate of
{{primary.bootstrap.dimensions.gene.metrics.pearson_r.estimate|.4f}}, and the two clustering
schemes agree closely. No chromosome, substitution class or genomic block is behaving unlike the
rest.

The one worth following up: **the size of the gap tracks gene density rather than being uniform.**
Bias is negative on every chromosome -- OpenSpliceAI lower everywhere -- but it is roughly twice
as large on the most gene-dense chromosomes as on the least. The same signature appears at the
gene level: the most divergent genes are large, exon-rich loci, and in every one of them it is
SpliceAI that scores higher. Substitution class, by contrast, explains very little. This is
consistent with the gain-side difference of section 4 being concentrated where there is simply
more splicing signal to disagree about, which is what one would expect if the two systems differ
in how readily they nominate a novel site rather than in where they think existing sites are.

### 9.1 Does the restricted region generalise?

Arms B, C and D live on chromosomes 1-7. If that region behaved unusually, the
seed conclusions in section 8 would not transfer. Comparing arm C with the
genome-wide arm A on identical statistics tests exactly that:

{{table:generalization}}

The restricted region is representative. Every statistic moves by an
amount far smaller than the effects being discussed: the maximum-score correlation differs by
{{generalization.absolute_differences.pearson_r|+.4f}}, mean absolute error by
{{generalization.absolute_differences.mae|+.5f}} and bias by
{{generalization.absolute_differences.bias|+.5f}} between the genome-wide arm and the same
comparison restricted to chromosomes 1-7. The seed conclusions of section 8 are therefore not an
artefact of where rs13's scoring happened to stop, and can be read as genome-wide to a good
approximation -- while remaining, strictly, a statement about the region actually measured.

## 10. Discussion

**The mask confound is resolved, and the asymmetry is real.** The earlier
{{study.prior_analysis_n|,d}}-variant comparison in this project found that losses agreed and gains
did not, but could not tell whether that was the models or the masking, because it compared an
unmasked OpenSpliceAI against a masked SpliceAI. With masking, annotation, distance and reference
all matched, the asymmetry is undiminished. It is a property of the trained systems.

**The difference is specifically about nominating new sites.** Loss scores are, under masking,
reported only at positions the shared annotation already calls splice sites; both systems are
answering "how much does this variant damage a site we both know about," and they agree -- closely
in value, almost perfectly in position, and to within roughly the spread of two training seeds. Gain
scores ask "is there a *new* site here," a question with no annotation to anchor it, and there the
two systems diverge three- to four-fold beyond seed noise, with OpenSpliceAI the more reticent. The
calibration figure makes the mechanism concrete: for a variant SpliceAI scores as a moderate gain,
OpenSpliceAI's median score is near zero until SpliceAI's own score is well above 0.5.

**What that does and does not license.** It is tempting to read reticence as either superior
specificity or inferior sensitivity, and this study supports neither reading. There is no truth set
here; a gain call that only SpliceAI makes may be a false positive it emits or a true positive
OpenSpliceAI misses, and these data cannot tell the difference. What can be said is that the two
systems are much closer to interchangeable for loss-of-site interpretation than for gain-of-site
interpretation, and that anyone porting an analysis between them should expect the gain channel --
not the loss channel -- to move.

**Practical guidance.** Transferring a threshold unchanged is reasonable: the achievable gain from
re-tuning is small, and agreement is best exactly where decisions are made, improving monotonically
from a 0.1 cutoff to a 0.8 one. Ensembling matters too. SpliceAI's published scores average five
models while each OpenSpliceAI arm here is a single checkpoint, and the seed contrast shows that a
second checkpoint moves the scores appreciably; an OpenSpliceAI ensemble would be expected to sit
closer to SpliceAI than either seed does alone. Testing that directly requires a third scored seed
and is the natural next experiment.

**On scale.** Three point three billion paired observations buy precision, not validity. Every
cluster-bootstrap interval here is narrow enough to be decorative, and no p-value in this report
would be informative. What the scale does buy is the ability to see structure -- the event
asymmetry, the threshold crossover, the gene-density gradient -- that a sample of a few hundred
thousand variants could not resolve, and to be confident those patterns are not sampling noise.

## 11. Limitations

1. **Concordance is not accuracy.** No truth set is used anywhere in this study.
   Where the two systems disagree, these data identify which scores higher, never
   which is right.
2. **Provisional coverage.** rs10 covers {{primary.chunks|,d}} of
   {{study.source_chunks|,d}} chunks and rs13 covers
   {{arms.D_rs13_matched.chunks|,d}}; scoring is stalled on GPU allocation, not
   on any analytical obstacle. Groups touching a missing chunk are conservatively
   excluded rather than joined across the gap.
3. **The seed and matched-method arms are regional.** They cover
   {{study.rs13_genomic_extent}} -- a contiguous region, not a random sample.
   Section 9.1 tests transfer but cannot guarantee it.
4. **Ensemble versus single checkpoint.** SpliceAI's published scores average
   five models; each OpenSpliceAI arm is one. Some of the method gap is an
   ensembling effect and is not separable here.
5. **Two-decimal comparator.** Section 5 bounds this effect but cannot remove it;
   rank statistics in particular are capped by the coarser grid.
6. **Approximate rank and distribution statistics.** Spearman, KS, Wasserstein
   and Jensen-Shannon are computed from {{primary.histogram_binning.bins|d}}-bin histograms.
   Those histograms also carry a small float-boundary artefact: a score is binned with
   `int(value x bins)`, so the two-decimal values
   {{primary.histogram_binning.affected_two_decimal_values}} -- whose binary representations sit a
   hair below the exact multiple -- land one bin low. This leaves
   {{primary.histogram_binning.empty_left_bin_count|d}} SpliceAI bins
   ({{primary.histogram_binning.empty_left_bins}}) empty and merges
   {{primary.histogram_binning.merged_observations|,d}} observations
   ({{primary.histogram_binning.merged_share|pct3}} of the paired set) into the neighbouring bin.
   It is visible as narrow gaps in the calibration figure. The additive moments, threshold tables,
   dominant-event and position statistics use direct comparisons and are unaffected, and none of
   the thresholds or transferred cutoffs reported here falls on an affected value.
7. **Cluster bootstraps are sensitivity intervals**, not confidence intervals
   over independent biological units. Overlapping genes, neighbouring variants
   and shared training data all induce dependence that gene or block resampling
   does not remove.
8. **Provenance class.** All scored outputs are `legacy_unprovenanced`: audited
   and hash-pinned, but without an embedded receipt binding them to a model
   identity.
9. **Gene coverage is not symmetric.** The published SpliceAI collection contains
   gene symbols absent from the scoring annotation OpenSpliceAI was given, so a
   fraction of source annotations has no counterpart by construction rather than
   by model failure.

## 12. Reproducibility

Every number above is read from `study_facts.json`, which is generated from the
reduced summaries; the narrative contains no transcribed values. The frozen
inputs are:

| Artefact | SHA-256 |
|:---|:---|
| `rs10_all.tsv` (arm A) | `{{study.pair_lists.rs10_all}}` |
| `rs10_rs13_overlap.tsv` (arm B) | `{{study.pair_lists.rs10_rs13_overlap}}` |
| `rs10_on_overlap.tsv` (arm C) | `{{study.pair_lists.rs10_on_overlap}}` |
| `rs13_on_overlap.tsv` (arm D) | `{{study.pair_lists.rs13_on_overlap}}` |
| rs10 audit manifest | `{{study.rs10_manifest_sha256}}` |
| rs13 audit manifest | `{{study.rs13_manifest_sha256}}` |
| analysis package | `{{study.analysis_code_sha256}}` |

Scheduler jobs: arm A {{study.slurm_jobs.A_rs10_genomewide}}; arm B
{{study.slurm_jobs.B_seeds_rs10_rs13}}; arm C {{study.slurm_jobs.C_rs10_matched}};
arm D {{study.slurm_jobs.D_rs13_matched}}.

Full per-arm tables are written as CSV alongside this document, and each arm also
carries the pipeline's own generated report. To rebuild:

```
python -m validation.concordance_study render-study \
  --runs-root <runs> --primary A_rs10_genomewide \
  --arm A_rs10_genomewide=A_rs10_genomewide:primary \
  --arm B_seeds_rs10_rs13=B_seeds_rs10_rs13:seed \
  --arm C_rs10_matched=C_rs10_matched:model \
  --arm D_rs13_matched=D_rs13_matched:model \
  --seed-arm B_seeds_rs10_rs13 --model-arm C_rs10_matched --model-arm D_rs13_matched \
  --template validation/concordance_study/templates/OpenSpliceAI_vs_SpliceAI_genome_wide.md \
  --study-meta <study_meta.json> --output-dir <out>
```
