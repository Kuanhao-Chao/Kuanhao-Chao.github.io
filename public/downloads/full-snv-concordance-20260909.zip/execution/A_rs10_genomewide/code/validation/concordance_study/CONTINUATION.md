# September 8 study continuation

## Scope and verified starting point

Continue Claude's September 8 plan, `i-would-like-to-steady-pony.md`: complete the
four-arm CPU analysis, annotated-site arm, redesigned figures, standalone study,
and new website technical report. The user explicitly chose the complete
event-level analysis, including an additional CPU pass. Finishing the GPU
scoring campaign is outside this continuation.

Verified September 8, 2026: the `study_20260908` run has 947 successful maps,
four successful reducers, and four successful renderers (Slurm exit 0:0).
Arm A contains 99,283 chunks / 3,334,708,099 exact-gene pairs; B/C/D contain
45,589 chunks each and 1,536,318,266 / 1,536,317,500 / 1,536,318,192 pairs.
All are provisional. The focused baseline is 54 passing tests and clean Ruff.
The frozen package digest is
`23ab219e25cb3bcf66786403848658ecd78fbe4f2dff51583c9aff974ca41e69`;
the annotation digest is
`e1aad08cf529cbf1310eac0f20344c23a4af7f54b0608fdbe94f2ce1af42d3b4`.

## Work sequence

1. Preserve existing runs and the pre-existing scorer changes. Add a versioned
   depth pass using the frozen A and B pair lists and existing audit/boundary
   contracts. Process B/C/D together on the exact three-way variant/gene
   intersection; equal chunk domains alone do not guarantee equal observations.
2. Add AG/AL/DG/DL statistics within chromosome, gene, block, substitution,
   dominant-event and site-distance strata; add site-conditioned score
   histograms and DP agreement. Keep 200 bins, thresholds
   0.05/0.1/0.2/0.5/0.8, 5,000 hash samples and 30,000 top discrepancies.
3. Test parsing, merges, boundaries, provenance and three-way membership; run
   a real-data pilot before CPU production. Freeze the core and depth code
   before submission and record jobs and resource measurements.
4. Complete dynamic-threshold reporting, per-event operating-point transfer,
   discordance distance taxonomy, collapsed-view analysis and matched stratum
   comparisons. Correct obsolete histogram diagnostics and seed-arm labels.
5. Independently recompute the 40-chunk validation window and new distance/event
   statistics. Reconcile exact counts and numerical tolerances before writing
   conclusions.
6. Render and visually inspect all figures, including the missing distance
   distributions and conditioned calibration/DP panels. Write both documents
   from one fact base; reject unresolved placeholders and INTERPRET markers.
7. Update the website's existing report and add the public, non-Scholar full-SNV
   report, run the website gates, deploy and verify the resulting pages.

## Interpretation contracts

SpliceAI is a comparator. Proximity is descriptive annotation context, not a
truth label or measured sensitivity/specificity. A symmetric 1–2 bp bin is not
an essential-dinucleotide label, and >500 bp from a site does not establish an
intronic location. The distance index pools internal splice boundaries across
genes on each contig, excludes transcript ends, and therefore differs from the
scorer's per-gene mask that includes transcript ends. Both limitations must be
visible. The top-k taxonomy describes selected extreme disagreements, not
their genome-wide prevalence. Retain legacy provenance classifications.

## Progress

- [x] Recover latest plan and session handoff; inspect code and run artifacts.
- [x] Confirm Slurm completion, code/annotation digests, focused tests and lint.
- [ ] Implement and test complete depth aggregation.
- [ ] Pilot, submit, and validate the additional CPU pass.
- [ ] Complete derived analyses and figures.
- [ ] Independently verify expanded results.
- [ ] Finish and publish both reports and the standalone artifacts.
