#!/usr/bin/env bash
set -euo pipefail
cd /data/ssalzbe1/khchao/OpenSpliceAI/results/full_snv_concordance/study_20260908_depth/production/A_rs10_genomewide/code
test "$(sha256sum /data/ssalzbe1/khchao/OpenSpliceAI/results/full_snv_concordance/study_20260908_depth/production/A_rs10_genomewide/checks.sha256 | cut -d' ' -f1)" = "$2"
sha256sum --check --status /data/ssalzbe1/khchao/OpenSpliceAI/results/full_snv_concordance/study_20260908_depth/production/A_rs10_genomewide/checks.sha256
if [ "$1" = map ]; then
  exec >/data/ssalzbe1/khchao/OpenSpliceAI/results/full_snv_concordance/study_20260908_depth/production/A_rs10_genomewide/logs/map-${SLURM_ARRAY_TASK_ID}.out 2>&1
  args=(map-primary --task-index "$SLURM_ARRAY_TASK_ID" --chunks-per-task 125 --output /data/ssalzbe1/khchao/OpenSpliceAI/results/full_snv_concordance/study_20260908_depth/production/A_rs10_genomewide/maps/map-${SLURM_ARRAY_TASK_ID}.json)
else
  exec >/data/ssalzbe1/khchao/OpenSpliceAI/results/full_snv_concordance/study_20260908_depth/production/A_rs10_genomewide/logs/reduce.out 2>&1
  args=(reduce-primary --input-dir /data/ssalzbe1/khchao/OpenSpliceAI/results/full_snv_concordance/study_20260908_depth/production/A_rs10_genomewide/maps --expected-task-count 795 --output /data/ssalzbe1/khchao/OpenSpliceAI/results/full_snv_concordance/study_20260908_depth/production/A_rs10_genomewide/summary.json)
fi
exec env -i PATH=/home/kchao10/miniconda3/envs/pytorch_cuda/bin:/usr/bin:/bin PYTHONPATH=/data/ssalzbe1/khchao/OpenSpliceAI/results/full_snv_concordance/study_20260908_depth/production/A_rs10_genomewide/code PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 MPLCONFIGDIR=/tmp/osai-depth-mpl /home/kchao10/miniconda3/envs/pytorch_cuda/bin/python3.9 -m validation.concordance_study.depth "${args[@]}" --pairs-file /data/ssalzbe1/khchao/OpenSpliceAI/results/full_snv_concordance/study_20260908_depth/production/A_rs10_genomewide/pairs.tsv --sites-file /data/ssalzbe1/khchao/OpenSpliceAI/results/full_snv_concordance/study_20260908_depth/production/A_rs10_genomewide/sites.tsv
