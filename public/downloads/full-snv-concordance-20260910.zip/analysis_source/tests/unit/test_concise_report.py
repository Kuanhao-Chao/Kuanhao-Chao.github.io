"""Behavioral checks for the revision's display data and document packaging."""
import importlib
import importlib.util

import pytest


def module():
    name = "validation.concordance_study.concise_figures"
    assert importlib.util.find_spec(name) is not None, "concise display module is missing"
    return importlib.import_module(name)


def test_site_call_rates_pool_counts_instead_of_averaging_rates():
    rows = [
        dict(distance="1-2", event="AG", threshold=0.5, n=10,
             both_positive=2, left_only=2, right_only=1),
        dict(distance="1-2", event="AG", threshold=0.5, n=90,
             both_positive=3, left_only=3, right_only=2),
        dict(distance="1-2", event="AG", threshold=0.2, n=100,
             both_positive=90, left_only=0, right_only=0),
    ]
    actual = module().pool_site_rates(rows, "AG", 0.5)
    assert actual == [{"distance": "1-2", "n": 100, "left": 10, "right": 8,
                       "left_rate": 0.1, "right_rate": 0.08, "ratio": 0.8}]


def test_site_call_rates_preserve_zero_and_undefined_denominators():
    rows = [dict(distance=">500", event="AL", threshold=0.5, n=100,
                 both_positive=0, left_only=0, right_only=0)]
    row = module().pool_site_rates(rows, "AL", 0.5)[0]
    assert row["left_rate"] == 0
    assert row["right_rate"] == 0
    assert row["ratio"] is None


def test_site_call_rates_reject_inconsistent_counts():
    rows = [dict(distance="1-2", event="AG", threshold=0.5, n=2,
                 both_positive=2, left_only=1, right_only=0)]
    with pytest.raises(ValueError, match="counts"):
        module().pool_site_rates(rows, "AG", 0.5)
