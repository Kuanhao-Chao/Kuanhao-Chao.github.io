import pytest


def module():
    from validation.concordance_study import concise_release
    return concise_release


def test_figure_contract_rejects_missing_or_duplicate_figures():
    figures = [{"id": "a", "document": "main", "number": 1, "title": "Title", "caption": "Caption", "alt": "Alt"}]
    with pytest.raises(ValueError, match="figure"):
        module().expand_figures("<!-- figure:unknown -->", figures, "main", "markdown")
    with pytest.raises(ValueError, match="figure"):
        module().expand_figures("<!-- figure:a -->\n<!-- figure:a -->", figures, "main", "markdown")
    with pytest.raises(ValueError, match="figure"):
        module().expand_figures("No figures", figures, "main", "markdown")


def test_same_caption_and_number_in_both_reading_formats():
    figures = [{"id": "a", "document": "main", "number": 1, "title": "Result", "caption": "Evidence.", "alt": "A comparison"}]
    for mode in ("markdown", "mdx"):
        rendered = module().expand_figures("<!-- figure:a -->", figures, "main", mode)
        assert "Figure 1. Result" in rendered
        assert "Evidence." in rendered
        assert "figure:a" not in rendered


def test_progress_context_does_not_mutate_scientific_facts():
    facts = {"study": {"date": "2026-09-09"}, "primary": {"agreement": {}, "thresholds": {}, "dp": {}}}
    for event in ("AG", "AL", "DG", "DL"):
        facts["primary"]["agreement"][event] = {"pearson_r": .7}
        facts["primary"]["thresholds"][event] = {"0.5": {"jaccard": .4, "call_rate_ratio_right_over_left": .8}}
        facts["primary"]["dp"][event] = {"0.5": {"within_0bp": .9}}
    snapshot = {"observed_at_utc": "2026-09-10T12:00:00+00:00", "seeds": {
        seed: {"total_chunks": 10, "current_counts": {"valid": 8, "missing": 1, "invalid": 1, "unverified": 0},
               "audit_at_utc": "2026-08-08T12:00:00+00:00"} for seed in ("rs10", "rs13")}}
    context = module().template_context(facts, snapshot)
    assert "revision" not in facts
    assert context["primary"] is facts["primary"]
    assert "8 of 10" in context["revision"]["progress_summary"]
    snapshot["seeds"]["rs10"]["current_counts"]["valid"] = 11
    with pytest.raises(ValueError, match="progress"):
        module().template_context(facts, snapshot)


def test_reusing_scientific_figures_refreshes_progress(monkeypatch, tmp_path):
    release = module()
    calls = []
    snapshot = {"observed_at_utc": "new observation"}
    monkeypatch.setattr(release.concise_figures, "progress_figure", lambda f, p, d: calls.append((p, d)))
    monkeypatch.setattr(release.concise_figures, "render", lambda *args: pytest.fail("scientific figures should be reused"))
    release.render_revision_figures({}, snapshot, tmp_path, tmp_path, skip_scientific=True)
    assert calls == [(snapshot, tmp_path / "figures")]
