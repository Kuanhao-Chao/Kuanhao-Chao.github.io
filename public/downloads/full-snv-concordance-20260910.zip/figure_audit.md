# Review of every original figure

| Original figure | Question | Key result | Revised figure | Decision |
|---|---|---|---|---|
| 1 | Coverage | Different counting units require explicit denominators. | S1 | Retain as methods support. |
| 2 | Conditional scores | Loss scores agree more closely; donor gain differs most. | 2 | Four larger event panels; omit MAX from the main figure. |
| 3 | Signed tails | Gain differences are directionally asymmetric. | S2 | Retain secondary distribution evidence. |
| 4 | Threshold agreement | Loss overlap is higher; donor gain has fewer shared calls. | 3 | Focus on Jaccard and relative call counts. |
| 5 | Threshold transfer | Matching call counts need not match membership. | S3 | Retain; clarify comparator-based objectives. |
| 6 | Output precision | Quantization explains only part of score disagreement. | S4 | Retain as a robustness check. |
| 7 | Dominant events | Largest-score labels compress nonexclusive event scores. | S5 | Retain ties/zeros and limit biological interpretation. |
| 8 | Selected positions | Shared gain calls usually select the same position. | 5 | Show exact rates and eligible counts; explain loss-mask constraint. |
| 9 | Boundary distance | Call rates and gain–loss differences vary with proximity. | 4A–D | Pool counts before division; distinguish variant and event position. |
| 10 | Context distributions | Proximity groups have different score distributions. | S6 | Retain supporting survival curves. |
| 11 | Conditional context | Gain score agreement is closer near boundaries. | 4E–F; S7 | Highlight gain medians; retain all four events in supplement. |
| 12 | Context positions | Agreement depends on a jointly called, sometimes small subset. | S8 | Retain denominators and undefined groups. |
| 13 | Seed contrast | Gain method differences exceed the observed seed contrast. | 6 | Compare four events on the identical three-way domain. |
| 14 | Seed contrast by gene | The gain–loss distinction extends across retained genes. | S9 | Retain; distinguish gene and annotation weighting. |
| 15 | Chromosomes/blocks | Regional MAX means vary, including extreme retained blocks. | S10 | Redraw with full vertical range; retain all eligible blocks. |
| 16 | Gene divergence | Gene averages vary with variant composition and coverage. | S11 | Retain descriptive candidates without enrichment claims. |
