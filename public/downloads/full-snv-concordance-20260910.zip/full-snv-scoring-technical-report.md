# Genome-wide comparison of predicted splicing effects between OpenSpliceAI and SpliceAI

## Abstract

OpenSpliceAI reproduces the SpliceAI architecture in PyTorch and supports retraining with different annotations and species. Here, we compare their predicted variant effects across the published collection of masked genic single-nucleotide variants. The frozen analysis contains 3,334,708,099 matched variant–gene annotations. Agreement differs by event: acceptor and donor loss scores have Pearson correlations of 0.900 and 0.906, compared with 0.681 and 0.597 for gains. At a cutoff of 0.5, OpenSpliceAI makes more loss calls and fewer gain calls, with the largest reduction in donor gain. Among jointly called gains, the models usually select the same position. On identical observations shared by two OpenSpliceAI training seeds and SpliceAI, gain-score differences exceed the observed seed difference more strongly than loss-score differences. These results describe agreement between a published ensemble and individual retrained checkpoints; they do not establish relative biological accuracy. We report inference progress separately from the frozen scientific results, which remain provisional because scoring is incomplete.



*Center for Computational Biology, Johns Hopkins University, Baltimore, MD, USA. Correspondence: kh.chao@jhu.edu. Scientific snapshot: 2026-09-09. Progress checked: 2026-09-10 15:46:22+00:00. [Supplement and detailed methods](/reports/full-snv-scoring-supplement/) · [Architecture and benchmarks](/reports/openspliceai-technical-report/).*

## Introduction

Splicing predictors assign scores to sequence variants that may create, strengthen, weaken, or disrupt
splice sites. OpenSpliceAI implements the SpliceAI architecture in PyTorch and provides models retrained
using MANE annotations [2]. Although the two systems show similar splice-site prediction performance,
that similarity does not establish that they assign the same effect to every variant. We therefore
compared their variant delta scores across the published SpliceAI collection of masked genic
single-nucleotide variants (SNVs).

The main question is whether agreement differs between **acceptor gain (AG), acceptor loss (AL), donor
gain (DG), and donor loss (DL)**. AG and DG measure increases in predicted acceptor and donor scores,
respectively; AL and DL measure decreases. Each event score summarizes the largest change within the
scoring window and is accompanied by its selected position. The maximum of the four scores, MAX,
summarizes overall predicted effect strength but does not identify a fifth event. A variant can have
more than one nonzero event score, so these categories should not be treated as mutually exclusive
classes of variants.

We examine score agreement, overlap of calls at the same cutoff, annotation context, and selected
positions. We then compare the difference between models with the difference between two independently
seeded OpenSpliceAI checkpoints. Throughout, SpliceAI serves as the comparator. The study contains no
experimental outcome labels with which to determine which discordant prediction is correct.

## Study design and inference progress

The comparison uses the published SpliceAI masked genic SNV collection on GRCh38. Here, genome-wide
refers to the collection's genomic extent: it does not mean every possible substitution at every GRCh38
base. The campaign partitions this collection into 100,000 chunks and scores two
MANE-trained OpenSpliceAI checkpoints, rs10 and rs13. These are training seeds, not cross-validation
folds. Each is a single model; the published SpliceAI scores come from a five-model ensemble.

The recorded scoring conditions use the same gene-assignment and masking annotation, reference,
50-bp event-search distance, and masked output setting. The OpenSpliceAI checkpoints
were trained using MANE, whereas assignment and masking in this campaign use the SpliceAI GENCODE v24
canonical gene table. Matching the scoring annotation therefore does not match the models' training
data. Model labels and settings are supported by campaign records; the legacy output files have been
structurally audited but lack embedded checkpoint receipts.

We pair annotations by chromosome, position, reference allele, alternate allele, and gene. Identical
repeats are collapsed, conflicting values are excluded, and missing predictions remain missing.
Consequently, a VCF row, a distinct variant allele, and a variant–gene annotation are different counting
units. The primary rs10 comparison contains 99,283 audited chunks and
3,334,708,099 paired annotations. The matched seed comparisons use a
three-way intersection of SpliceAI, rs10, and rs13 after duplicate resolution and chunk-boundary
joining. All three contrasts therefore use exactly
1,536,316,689 observations.

At the current metadata check, rs10 has 99,283 of 100,000 chunks (99.283%) with an audited-valid state and unchanged metadata; 693 are missing, 24 invalid, and 0 changed or unverified; rs13 has 45,597 of 100,000 chunks (45.597%) with an audited-valid state and unchanged metadata; 54,382 are missing, 21 invalid, and 0 changed or unverified. These counts carry forward the 2026-08-08 content audit; they do not constitute a new VCF content audit. Figure 1 records the separately observed scheduler state.

<figure><img src="figures/main01_progress.png" alt="Two OpenSpliceAI seeds remain incomplete; the scientific snapshot is frozen." /><figcaption>Figure 1. Inference progress and analyzed coverage. Current input/output size and modification-time checks are compared with the dated audit manifests. Unchanged metadata carries forward an audited state; it is not a new content audit. Missing, invalid and changed/unverified chunks remain separate. Job reasons are a dated scheduler observation, not a completion forecast. The lower panel shows the distinct primary and exact three-way analysis domains.</figcaption></figure>

Figure 1 separates the current progress evidence from the data already analyzed. The CPU summaries are
complete for their selected inputs; the inference campaign is incomplete. The matched domain covers
chunks 1-46,920, ending at chr7:152,826,580 and is not a random genomic sample. We retain this frozen scientific
snapshot for the present revision so that a progress update cannot silently alter the reported
comparisons. Detailed coverage counts, exclusion rules, and provenance are provided in the supplement.

## Loss scores agree more closely than gain scores

The main event-level difference is consistent for acceptors and donors: loss scores agree more closely
than gain scores (Figure 2). Pearson correlations are 0.900 for AL and
0.906 for DL, compared with 0.681 for AG
and 0.597 for DG. Thus, donor gain shows the lowest score correlation,
whereas the two loss events have similar correlations. The conditional score distributions also show
that gain disagreement involves the magnitude of the scores, rather than only a change in their rank.

<figure><img src="figures/main02_score_agreement.png" alt="Conditional score distributions for acceptor gain, acceptor loss, donor gain and donor loss." /><figcaption>Figure 2. Loss scores agree more closely than gain scores. OpenSpliceAI scores conditional on SpliceAI scores for the primary paired variant–gene annotations. Points are medians; dark and light intervals contain the central 50% and 90%. The dashed diagonal denotes equal scores. Quantiles use stored 200-bin histograms (width 0.005); empty comparator bins remain gaps. Pearson correlations use the original scores and include shared zeros. The panels describe score agreement, not calibration against experimental outcomes.</figcaption></figure>

For losses, the conditional median OpenSpliceAI score follows the equal-score line more closely. For
gains, the median remains substantially below that line across much of the SpliceAI score range,
particularly for donor gain. Nevertheless, the intervals are broad: the conditional median describes
the center of the distribution, not the response of every variant. A lower median should not be read
as a rule that OpenSpliceAI always assigns a lower gain score.

Across all paired annotations, the signed mean difference, defined as OpenSpliceAI minus SpliceAI,
is negative for AG and DG and slightly positive for AL and DL. The corresponding mean absolute
differences are 0.00148, 0.00147,
0.00037, and 0.00033, respectively. These small global
averages reflect a population dominated by low and zero scores. They should be interpreted together
with the score distributions and the overlap of positive calls, not as evidence that the models are
interchangeable.

SpliceAI reports two decimal places and OpenSpliceAI reports five. Matching output precision increases
exact-value agreement, but substantial absolute disagreement remains beyond the half-grid rounding
allowance (Supplementary Figure S4). We therefore emphasize score magnitude and call overlap rather
than exact matches. MAX has a Pearson correlation of 0.795, but this
aggregate obscures the stronger distinction between gains and losses.

## Call overlap differs between the four events

A common score cutoff does not necessarily identify the same annotations in both models. Figure 3
shows positive-call Jaccard overlap and the ratio of OpenSpliceAI to SpliceAI call counts across cutoffs.
Jaccard is the number of shared positive calls divided by the number called by either model. It excludes
the shared negatives that dominate the full population. A call-count ratio below one means that
OpenSpliceAI makes fewer calls at that cutoff; it does not measure specificity.

<figure><img src="figures/main03_call_agreement.png" alt="Jaccard overlap and relative call count across common event-score cutoffs." /><figcaption>Figure 3. Gain calls overlap less, especially donor gain. A, shared positive calls divided by their union. B, OpenSpliceAI calls divided by SpliceAI calls; the dashed line denotes equal counts and the vertical scale is logarithmic. Colors and marker shapes distinguish the four events. Curves use approximate histogram cutoffs; larger symbols at 0.5 show exact counters. Shared negatives do not enter Jaccard. Fewer calls do not establish higher specificity.</figcaption></figure>

| Event | Pearson r | Jaccard at 0.5 | OpenSpliceAI / SpliceAI calls |
|---|---:|---:|---:|
| AG | 0.681 | 0.413 | 0.788 |
| AL | 0.900 | 0.649 | 1.291 |
| DG | 0.597 | 0.284 | 0.522 |
| DL | 0.906 | 0.677 | 1.164 |

*Table 1. Event-level agreement on 3,334,708,099 paired variant–gene
annotations. Jaccard and relative call counts use the same cutoff of 0.5 in both models. Pearson
correlation uses all paired scores for the stated event. The models can assign more than one event to
an annotation.*

At 0.5, loss-call overlap is higher for both acceptors and donors. OpenSpliceAI makes more AL and DL
calls than SpliceAI, while making fewer AG and DG calls. Donor gain has both the lowest overlap and the
smallest relative call count: OpenSpliceAI calls approximately half as many DG annotations as SpliceAI.
Acceptor gain also differs, but less strongly. This separates two comparisons that MAX combines:
whether an effect is a gain or loss, and whether it involves an acceptor or donor.

The direction and size of call-volume differences depend on the cutoff, so Table 1 is an interpretable
snapshot rather than a universal operating point. For example, the MAX call-count ratio changes from
0.607 at 0.2 to
1.060 at 0.8. Matching a model's total number
of calls also need not recover the same annotations. The supplementary threshold-transfer analysis
therefore reports call-volume matching and comparator-agreement optimization separately.

Dominant-event categories provide an additional description of these differences (Supplementary
Figure S5). They identify the largest score within each model, retaining ties and all-zero cases.
Because they discard the other three scores and depend on output precision, they are supporting
summaries rather than independent biological labels. The event-specific results remain the primary
basis for comparing predicted splicing effects.

## Annotation context helps locate the differences

We next grouped variants by distance to the nearest annotated internal splice boundary. The index
contains 351,042 unique coordinates derived from the scoring annotation, with donor
and acceptor roles assigned by strand. It pools boundaries across genes and excludes transcript ends.
This provides a common description of local annotation context, but does not assign each variant to
a particular transcript or establish whether it is intronic.

<figure><img src="figures/main04_boundary_context.png" alt="Call rates by variant distance and conditional gain-score medians near and far from internal boundaries." /><figcaption>Figure 4. Annotation context locates gain and loss differences. A–D, event score ≥ 0.5 as a fraction of all paired variant–gene annotations in each distance group. Counts are pooled across donor/acceptor boundary types before division. The rate axis is logarithmic; printed zeros indicate measured zero calls. E–F, histogram-derived conditional medians for variants at/within 2 bp versus more than 500 bp from a pooled internal boundary. The boundary index is strand-aware and excludes transcript ends. Variant distance is neither predicted-event distance nor a transcript-specific intronic/exonic classification.</figcaption></figure>

Both models concentrate high-scoring calls near annotated boundaries (Figure 4A–D). At 1–2 bp, their
loss-call volumes are similar. Farther away, within the 3–50-bp groups, OpenSpliceAI makes more loss
calls. For gains, SpliceAI generally makes more calls at 0.5 across the displayed distance groups,
with the larger reduction in OpenSpliceAI donor-gain calls particularly apparent beyond the immediate
boundary neighborhood. The rates divide by all paired annotations in each distance group, so the
much larger distant population does not automatically produce a higher plotted rate.

These patterns refine the global gain–loss comparison. Similar loss-call volumes close to a boundary
can coexist with higher OpenSpliceAI loss-call volumes elsewhere in the search window. Likewise, a
similar gain-call volume in one proximity group would not establish that the same variants or score
magnitudes agree. The conditional gain-score medians in Figure 4E–F show closer agreement near
boundaries than more than 500 bp away across much of the comparator score range. The full score
distributions and conditional intervals are retained in Supplementary Figures S6–S7.

Masking constrains the interpretation. For each variant and gene, the scorer selects the nearest exon
boundary, including transcript ends. A loss score is retained only when its selected event position
matches that boundary; a gain is suppressed when its selected position matches it. The mask acts on
the predicted event position, whereas Figure 4 groups by the variant position. The pooled internal
boundary index and the per-gene masking boundary set are therefore not identical. In particular, very
few distant loss calls under this setup should not be interpreted as an independently measured
biological absence of loss effects.

The symmetric 1–2-bp group also should not be equated with the essential splice dinucleotides, and a
distance greater than 500 bp does not establish a deep-intronic location. The context analysis locates
patterns for follow-up. It cannot determine whether a lower gain score reflects a missed true event or
a reduction in false-positive predictions.

## Jointly called gains usually select the same position

A difference in effect strength need not imply a difference in the selected splice-site position.
Among annotations for which both event scores are at least 0.5, the models select identical positions
for 96.83% of AG calls and 98.09% of DG calls (Figure 5).
Thus, although gain-call overlap is limited, the subset called by both models usually points to the
same location. This distinction is useful when interpreting a discordant score: the disagreement can
concern how strongly the model responds at a shared selected site.

<figure><img src="figures/main05_positions.png" alt="Exact predicted-position agreement among jointly called variant–gene annotations." /><figcaption>Figure 5. Jointly called gains usually select the same position. Both scores for the specified event must be ≥ 0.5. Labels give exact-position agreement and eligible annotation counts. The point axis spans 90–101% to resolve these high percentages. Loss-position agreement is constrained by the common mask, which retains a loss only at the selected per-gene boundary; it is not an independent biological validation. Calls unique to one model are excluded.</figcaption></figure>

This result is conditional on both models making a call. It excludes annotations called by only one
model, which account for a substantial part of the gain disagreement in Figure 3. High positional
agreement within the shared subset therefore cannot be generalized to all predicted gains. The
supplement reports other score cutoffs, position tolerances, and proximity groups, with their eligible
counts rather than treating an empty group as zero agreement.

The loss events have 100.00% and 100.00% exact positional
agreement at the same cutoff. Under the shared mask, both retained loss scores are constrained to the
selected per-gene boundary. This agreement is expected from the scoring setup and does not provide an
independent test of the loss mechanism. More generally, selecting the same position does not establish
that the site is used in vivo. Score strength, positive-call membership, and position agreement should
therefore be reported together.

## Gain disagreement is larger than the observed seed difference

To assess the scale of the model difference, we compared rs10 with rs13 and compared each checkpoint
with SpliceAI on the exact same three-way variant–gene intersection. This avoids attributing different
comparison domains to model variability. Figure 6 shows the mean absolute score difference for each
contrast and the ratio of each SpliceAI–OpenSpliceAI difference to the rs10–rs13 difference.

<figure><img src="figures/main06_seed_comparison.png" alt="Mean absolute differences and method-to-seed ratios on the identical three-way intersection." /><figcaption>Figure 6. Gain differences exceed the observed seed contrast. A, mean absolute differences for rs10–rs13 and for each checkpoint versus SpliceAI. B, each method difference divided by the rs10–rs13 difference; one denotes equal mean differences. All contrasts use exactly the same variant–gene annotations. Two seeds provide one observed contrast, not a population estimate of training variability. Single OpenSpliceAI checkpoints and the published SpliceAI ensemble remain different comparison units.</figcaption></figure>

For rs10, the ratios are 3.35 for AG and
3.92 for DG, compared with
1.13 for AL and
1.17 for DL. The corresponding rs13 comparisons
show the same gain–loss pattern. The gain-score difference between model collections is therefore
larger relative to the observed seed contrast, with donor gain again showing the stronger difference.
For losses, the average differences are closer in magnitude to those between the two OpenSpliceAI seeds.

A ratio near one means that two mean absolute differences are similar; it does not establish
interchangeability or demonstrate that seed variation explains the discrepancy. Only two checkpoints
are available, so this contrast does not estimate variability across the full population of training
runs. It also compares individual OpenSpliceAI checkpoints with an ensemble. Differences in training,
checkpoint identity, implementation, and ensembling remain combined in the model contrast.

The pattern extends across many genes within the matched region (Supplementary Figure S9), rather than
being confined to a few extreme gene averages. However, those gene-level ratios weight genes differently
from the observation-weighted global ratio. The restricted domain and common-gene requirement also
limit extrapolation to unscored regions. We retain the full gene, chromosome, and genomic-block results
as supporting evidence, without treating the matched region as a random sample of the genome.

## Discussion

This comparison identifies a consistent difference between predicted gains and losses. Loss scores
agree more closely, while gain scores show larger differences in magnitude and positive-call
membership. Donor gain differs more strongly than acceptor gain. At the same time, jointly called
gains usually select the same position, and the magnitude of disagreement varies with annotation
context. These observations show why a single correlation or overall agreement percentage is
insufficient to describe the relationship between the two score collections.

The results extend the experiments in our eLife paper [2], which evaluated splice-site prediction,
mutagenesis around selected splice sites, and specific cryptic-splicing examples. The paper's
mutagenesis comparisons used five-model ensembles, whereas the present study compares individual
OpenSpliceAI checkpoints with the published SpliceAI ensemble across masked genic variants. The
experiments differ in sampling, averaging, and the predicted quantity being compared. Similarity of
local sequence-response patterns therefore does not require identical genome-wide variant delta
scores, and the correlation values from the two experiments should not be compared as equivalent
performance measures.

The principal unresolved question is which discordant predictions correspond to observed changes in
splicing. Answering it requires independently measured outcomes that include shared calls and calls
unique to each model. An ensemble-matched comparison would also help assess how much of the current
difference persists after matching the number of checkpoints. Neither experiment is part of this
revision. The present results provide a reproducible description of where the predictions agree and
where further evaluation would be most informative.

## Methods and data availability

The analysis streams audited source/output pairs into additive counters, fixed-width histograms, and
explicit call tables. Exact configured cutoffs are 0.05, 0.1, 0.2, 0.5, and 0.8; histogram-based curves
and conditional quantiles use 200 bins of width 0.005 and are approximate. Independent implementations
passed 11,195 primary and 40,020
matched checks on real-data windows. These verify numerical implementation, not biological accuracy.
The selected inputs remain incomplete, and their legacy provenance classification is retained.

The [supplement](/reports/full-snv-scoring-supplement/) contains the full methods, figure audit,
secondary results, and links to every original table. The [revised study bundle](/downloads/full-snv-concordance-20260910.zip)
contains both reading copies, figure PNGs and vector PDFs, plotting inputs, the unchanged scientific
fact base, the separate progress snapshot, and source code. A [browser reading copy](/downloads/full-snv-concordance-20260910.html)
and [checksums](/downloads/full-snv-concordance-20260910-SHA256SUMS.txt) are also available. The original
[September 9 study bundle](/downloads/full-snv-concordance-20260909.zip) is preserved.


## References

1. [Jaganathan K, Kyriazopoulou Panagiotopoulou S, McRae JF, et al. Predicting Splicing from Primary Sequence with Deep Learning. Cell, 2019.](https://doi.org/10.1016/j.cell.2018.12.015)

2. [Chao K-H, Mao A, Liu A, Salzberg SL, Pertea M. OpenSpliceAI provides an efficient modular implementation of SpliceAI enabling easy retraining across nonhuman species. eLife 14:RP107454, 2025.](https://doi.org/10.7554/eLife.107454.3)